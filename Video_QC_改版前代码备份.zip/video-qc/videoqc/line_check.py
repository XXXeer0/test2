from .classify import CONFLICT, DYNAMIC

KIND_EXCEEDED = "dynamic_line_count_exceeded"
KIND_LINE_UNCERTAIN = "line_count_uncertain"
KIND_REGION_CONFLICT = "region_conflict"


def sample_record(t_ms, cls_lines):
    dyn = [l for l in cls_lines if l.cls == DYNAMIC]
    conflict = [l for l in cls_lines if l.cls == CONFLICT]
    unknown = [l for l in cls_lines if l.cls not in (DYNAMIC, CONFLICT) and l.cls != "fixed"]
    return {
        "t_ms": t_ms,
        "dynamic_count": len(dyn),
        "dynamic_text": "\n".join(l.text for l in dyn),
        "conflict_count": len(conflict),
        "conflict_texts": [l.text for l in conflict],
        "unknown_count": len(unknown),
        "unknown_texts": [l.text for l in unknown],
    }


def _hit(rec):
    if not rec.get("ok", False):
        return {KIND_EXCEEDED: False, KIND_LINE_UNCERTAIN: False, KIND_REGION_CONFLICT: False}
    dc = rec.get("dynamic_count", 0)
    cc = rec.get("conflict_count", 0)
    exceed = dc >= 2
    uncertain = cc >= 1
    conflict = cc >= 1
    return {
        KIND_EXCEEDED: exceed,
        KIND_LINE_UNCERTAIN: uncertain,
        KIND_REGION_CONFLICT: conflict,
    }


def build_line_issues(samples, interval_ms):
    issues = []
    active = {}

    def close(kind):
        cur = active.pop(kind, None)
        if cur:
            issues.append(cur)

    for rec in samples:
        hits = _hit(rec)
        for kind, hit in hits.items():
            if not hit:
                if kind in active and rec["t_ms"] - active[kind]["end_ms"] > interval_ms * 1.5:
                    close(kind)
                continue
            cur = active.get(kind)
            if cur is None:
                cur = {
                    "kind": kind,
                    "status": "suspected" if kind == KIND_EXCEEDED else "inconclusive",
                    "start_ms": rec["t_ms"],
                    "end_ms": rec["t_ms"],
                    "frames": [],
                }
                active[kind] = cur
            cur["end_ms"] = rec["t_ms"]
            frame = {
                "t_ms": rec["t_ms"],
                "dynamic_count": rec["dynamic_count"],
                "ocr_text": rec["dynamic_text"] + (
                    "\n[conflict] " + " | ".join(rec["conflict_texts"]) if rec["conflict_texts"] else ""
                ) if (rec["dynamic_text"] or rec["conflict_texts"]) else "",
                "conflict_texts": rec["conflict_texts"],
            }
            cur["frames"].append(frame)
        for kind in list(active.keys()):
            if rec["t_ms"] - active[kind]["end_ms"] > interval_ms * 1.5:
                close(kind)
    for kind in list(active.keys()):
        close(kind)

    for iss in issues:
        iss["observed_dynamic_lines"] = max((f["dynamic_count"] for f in iss["frames"]), default=0)

    issues.sort(key=lambda i: i["start_ms"])
    return issues


def derive_check_status(issues, has_valid_samples, has_coverage_gap):
    if not has_valid_samples:
        return "unavailable"
    if any(i["status"] == "suspected" for i in issues):
        return "suspected"
    if issues or has_coverage_gap:
        return "inconclusive"
    return "no_issue_observed"
