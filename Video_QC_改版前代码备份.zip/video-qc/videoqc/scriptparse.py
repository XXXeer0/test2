"""剧本解析：从原始剧本中自动提取角色台词。

设计原则（对应问题分析与改进方案.txt 改进 2）：
- 识别「角色名：台词」「角色名（动作）：台词」「角色名 os：台词/旁白：台词」
  （全角/半角冒号均可）；
- 剔除场景标题（第X场/集/话/回、"35-1 日 内 …"式场次头、INT./EXT.、内景/外景）、
  整行舞台指示（（）【】整行包裹、▲/△ 开头）、人物表行（人物：/角色：）、空行；
- 安全原则：绝不静默丢弃——解析不出来的非空行默认保留为台词（无角色标注），
  由用户在界面中检查删除；
- 一行角色格式都没识别到时，整体按纯文本处理（与旧工作流完全一致），不装懂；
- 本模块只做输入预处理，不改对齐核心（align.py）的任何行为。
"""

import re
from dataclasses import dataclass, field

# 角色台词头：角色名（1~12 字，不含空白/括号/冒号）+ 可选（动作提示）
#   + 可选 Vo/os/旁白类画外音·内心独白标记（如 "贺砚庭 os："、"程子莲 Vo："）
#   + 冒号 + 正文（Vo 紧贴角色名的情况在 _match_role_line 里剥离）
ROLE_LINE = re.compile(
    r"^([^\s：:（()]{1,12})\s*(?:[（(][^）)]*[）)])?"
    r"(?:\s*(?:V\.O\.|Vo|O\.S\.|os|旁白|内心独白|内心))?\s*[：:]\s*(.+)$",
    re.IGNORECASE,
)
# 角色名尾部误带 Vo/os 标记的剥离（"程子莲Vo" -> "程子莲"）
ROLE_TAIL_MARKER = re.compile(r"(?:V\.O\.|Vo|O\.S\.|os)$", re.IGNORECASE)
# 场景标题：第X场/幕/章/集/话/回、场景X、INT./EXT.、内景/外景 等（行首）
SCENE_HEAD = re.compile(
    r"^(第\s*[0-9一二三四五六七八九十百千]+\s*[场幕章节集话回]|场景\s*[0-9一二三四五六七八九十百千]*"
    r"|(?:INT|EXT)[\.．]|内景|外景|日景|夜景|时间[:：]|地点[:：])",
    re.IGNORECASE,
)
# 场次头：剧本常用编号场景行（行首数字-数字），
#   两种顺序都认："35-1 日 内 地点" 与 "55-1 地点 日 外"（日/夜/内/外需独立成词）
SLUG_HEAD = re.compile(
    r"^\d{1,4}\s*[-－—－]\s*\d{0,4}\s+(?:.*\s)?(?:日|夜|晨|清晨|黄昏|内|外)(?:\s|$)")
# 人物表：整行列出出场角色（避免被当成角色台词）
CAST_LIST = re.compile(r"^(?:出场人物|登场人物|人物|角色)\s*[：:]")
# 整行舞台指示：被（）或【】整行包裹，或以 ▲/△ 记号开头
STAGE_LINE = re.compile(r"^[（(][^）)]*[）)]$|^[【\[][^】\]]*[】\]]$|^[▲△]")

MAX_ROLE_NAME = 12


@dataclass
class DialogueLine:
    index: int          # 台词序号（从 1 起，即对齐段落 para_index + 1）
    role: str           # 角色名；无法识别角色的行保留为空串
    text: str           # 台词正文（不含角色名与冒号）
    source_line: int    # 在原始文本中的行号（从 1 起，供人工回查）


@dataclass
class ParseResult:
    parsed: bool                       # 是否识别出剧本格式
    lines: list = field(default_factory=list)    # DialogueLine 列表
    removed: list = field(default_factory=list)  # 被剔除的行 [{line_no, text, reason}]
    stats: dict = field(default_factory=dict)
    plain_text: str = ""               # 提取后的纯台词文本（每条一行，喂给对齐）

    def to_meta(self):
        """供界面传递给管道的元数据（角色名按台词序号对齐）。"""
        return {
            "plain_text": self.plain_text,
            "lines": [
                {"index": l.index, "role": l.role, "text": l.text} for l in self.lines
            ],
        }


def _is_scene_head(line):
    return bool(SCENE_HEAD.match(line)) or bool(SLUG_HEAD.match(line))


def _is_cast_list(line):
    return bool(CAST_LIST.match(line))


def _is_stage_direction(line):
    return bool(STAGE_LINE.match(line))


def _match_role_line(line):
    m = ROLE_LINE.match(line)
    if not m:
        return None, None
    role, text = m.group(1), m.group(2).strip()
    # 剥离紧贴角色名的 Vo/os 尾巴（"程子莲Vo：" -> 角色"程子莲"）
    role = ROLE_TAIL_MARKER.sub("", role).strip()
    # 场景标题误伤防护：行如 "第三场：医院走廊" 会被角色规则匹配，先判场景
    if _is_scene_head(line):
        return None, None
    if not text:
        return None, None
    return role, text


def parse_script(text):
    text = (text or "").replace("\r\n", "\n").replace("\r", "\n")
    lines = []
    removed = []
    role_head_count = 0
    unlabeled_kept = 0
    roles = {}

    raw_lines = text.split("\n")
    cur = None  # 当前正在累积续行的台词

    def push_dialogue(role, body, line_no):
        nonlocal cur
        cur = DialogueLine(index=len(lines) + 1, role=role, text=body, source_line=line_no)
        lines.append(cur)
        if role:
            roles[role] = roles.get(role, 0) + 1

    for no, raw in enumerate(raw_lines, 1):
        line = raw.strip()
        if not line:
            removed.append({"line_no": no, "text": raw, "reason": "空行"})
            cur = None
            continue
        if _is_scene_head(line):
            removed.append({"line_no": no, "text": line, "reason": "场景标题"})
            cur = None
            continue
        if _is_stage_direction(line):
            removed.append({"line_no": no, "text": line, "reason": "舞台指示（整行括注）"})
            cur = None
            continue
        if _is_cast_list(line):
            removed.append({"line_no": no, "text": line, "reason": "人物表"})
            cur = None
            continue
        role, body = _match_role_line(line)
        if role is not None:
            role_head_count += 1
            push_dialogue(role, body, no)
            continue
        # 续行：上一行是台词且本行不构成新台词头 -> 并入上一条
        if cur is not None:
            cur.text = (cur.text + " " + line).strip()
            continue
        # 无法识别的非空行：安全原则，默认保留为台词（无角色标注）
        unlabeled_kept += 1
        push_dialogue("", line, no)

    parsed = role_head_count > 0
    if not parsed:
        # 降级：按纯文本原样处理（与旧工作流一致），不丢任何字符
        return ParseResult(
            parsed=False,
            lines=[],
            removed=[],
            stats={"parsed": False, "role_head_count": 0},
            plain_text=text,
        )

    plain = "\n".join(l.text for l in lines)
    scene_n = sum(1 for r in removed if r["reason"].startswith("场景"))
    stage_n = sum(1 for r in removed if r["reason"].startswith("舞台"))
    blank_n = sum(1 for r in removed if r["reason"] == "空行")
    cast_n = sum(1 for r in removed if r["reason"] == "人物表")
    stats = {
        "parsed": True,
        "role_head_count": role_head_count,
        "dialogue_count": len(lines),
        "unlabeled_kept": unlabeled_kept,
        "roles": sorted(roles.keys()),
        "removed": {
            "scene": scene_n,
            "stage_direction": stage_n,
            "blank": blank_n,
            "cast_list": cast_n,
        },
    }
    return ParseResult(parsed=True, lines=lines, removed=removed, stats=stats, plain_text=plain)
