from dataclasses import dataclass, field

from .config import roi_cover_ratio

DYNAMIC = "dynamic"
FIXED = "fixed"
CONFLICT = "conflict"
UNKNOWN = "unknown"


@dataclass
class ClassifiedLine:
    text: str
    bbox_full_norm: list
    bbox_crop_norm: list
    boxes: list = field(default_factory=list)
    cls: str = UNKNOWN
    cover_dynamic: float = 0.0
    cover_fixed: float = 0.0

    def to_dict(self):
        return {
            "text": self.text,
            "cls": self.cls,
            "bbox_full_norm": [round(v, 6) for v in self.bbox_full_norm],
            "cover_dynamic": round(self.cover_dynamic, 4),
            "cover_fixed": round(self.cover_fixed, 4),
            "word_count": len(self.boxes),
        }


def crop_bbox_to_full_norm(bbox, crop_w, crop_h):
    x0, y0, x1, y1 = bbox
    xn0 = x0 / float(crop_w)
    xn1 = x1 / float(crop_w)
    yn0 = 0.5 + (y0 / float(crop_h)) * 0.5
    yn1 = 0.5 + (y1 / float(crop_h)) * 0.5
    return [xn0, yn0, xn1, yn1]


def classify_line(bbox_full_norm, dyn_roi, fixed_roi):
    cd = roi_cover_ratio(dyn_roi, bbox_full_norm) if dyn_roi else 0.0
    cf = roi_cover_ratio(fixed_roi, bbox_full_norm) if fixed_roi else 0.0
    if cd > 0.0 and cf > 0.0:
        return CONFLICT, cd, cf
    if cd >= 0.8:
        return DYNAMIC, cd, cf
    if cf >= 0.8:
        return FIXED, cd, cf
    if cd > 0.0 or cf > 0.0:
        return CONFLICT, cd, cf
    return UNKNOWN, cd, cf


def classify_lines(lines, crop_w, crop_h, dyn_roi, fixed_roi):
    out = []
    for line in lines:
        full = crop_bbox_to_full_norm(line.bbox, crop_w, crop_h)
        crop_norm = [line.bbox[0] / crop_w, line.bbox[1] / crop_h,
                     line.bbox[2] / crop_w, line.bbox[3] / crop_h]
        cls, cd, cf = classify_line(full, dyn_roi, fixed_roi)
        out.append(ClassifiedLine(
            text=line.text,
            bbox_full_norm=full,
            bbox_crop_norm=crop_norm,
            boxes=line.boxes,
            cls=cls,
            cover_dynamic=cd,
            cover_fixed=cf,
        ))
    return out
