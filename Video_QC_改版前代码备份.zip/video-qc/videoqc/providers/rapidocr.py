from .base import OcrFrame, OcrProvider, OcrWord

INSTALL_HINT = "未安装本地 OCR 运行库：pip install rapidocr-onnxruntime"


class LocalRapidOcr(OcrProvider):
    name = "rapidocr"

    def __init__(self):
        self._engine = None
        self.device = "cpu"
        self.engine_desc = "RapidOCR (PP-OCRv4 ONNX)"

    def _ensure(self):
        if self._engine is None:
            try:
                from rapidocr_onnxruntime import RapidOCR
            except ImportError:
                try:
                    from rapidocr import RapidOCR
                except ImportError:
                    raise ImportError(INSTALL_HINT)
            self._engine = RapidOCR()
        return self._engine

    def recognize(self, image_bytes, t_ms):
        try:
            engine = self._ensure()
            out = engine(image_bytes)
        except ImportError:
            return OcrFrame(ok=False, error=INSTALL_HINT, provider_meta={"provider": self.name})
        except Exception as e:
            return OcrFrame(ok=False, error="local ocr failed: %s" % e,
                            provider_meta={"provider": self.name})
        words = self._parse(out)
        return OcrFrame(
            ok=True,
            words=words,
            empty=(len(words) == 0),
            provider_meta={"provider": self.name, "engine": self.engine_desc, "device": self.device},
        )

    def _parse(self, out):
        if out is None:
            return []
        result = out[0] if isinstance(out, tuple) else out
        if result is None:
            return []
        words = []
        if hasattr(result, "boxes") and hasattr(result, "txts"):
            boxes = result.boxes or []
            txts = result.txts or []
            scores = getattr(result, "scores", None) or []
            for i, box in enumerate(boxes):
                text = str(txts[i]) if i < len(txts) else ""
                score = float(scores[i]) if i < len(scores) else 1.0
                quad = [(float(p[0]), float(p[1])) for p in box]
                if text:
                    words.append(OcrWord(text=text, quad=quad, probability=score))
            return words
        for item in result:
            if not isinstance(item, (list, tuple)) or len(item) < 2:
                continue
            box, text = item[0], str(item[1])
            score = float(item[2]) if len(item) > 2 and item[2] is not None else 1.0
            quad = [(float(p[0]), float(p[1])) for p in box]
            if text:
                words.append(OcrWord(text=text, quad=quad, probability=score))
        return words
