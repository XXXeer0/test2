import json
import os

from .aliyun import AliyunOcr
from .base import OcrConfigError, OcrProvider
from .rapidocr import LocalRapidOcr
from .scripted import ScriptedOcr

CREDENTIALS_FILENAME = os.path.join(os.path.expanduser("~"), ".videoqc", "credentials.json")
ENV_ID = "ALIBABA_CLOUD_ACCESS_KEY_ID"
ENV_SECRET = "ALIBABA_CLOUD_ACCESS_KEY_SECRET"


def resolve_aliyun_credentials(ui_values=None):
    if ui_values and ui_values.get("access_key_id") and ui_values.get("access_key_secret"):
        return ui_values["access_key_id"], ui_values["access_key_secret"]
    env_id = os.environ.get(ENV_ID)
    env_secret = os.environ.get(ENV_SECRET)
    if env_id and env_secret:
        return env_id, env_secret
    if os.path.isfile(CREDENTIALS_FILENAME):
        try:
            with open(CREDENTIALS_FILENAME, "r", encoding="utf-8") as f:
                cred = json.load(f)
            cid = cred.get("aliyun_access_key_id")
            csec = cred.get("aliyun_access_key_secret")
            if cid and csec:
                return cid, csec
        except (OSError, json.JSONDecodeError):
            pass
    return None, None


def create_provider(cfg, credentials=None):
    cloud = cfg.get("cloud") or {}
    provider = cloud.get("provider")
    if provider == "aliyun":
        ak_id, ak_sec = resolve_aliyun_credentials(credentials)
        return AliyunOcr(
            access_key_id=ak_id,
            access_key_secret=ak_sec,
            timeout_ms=cloud.get("timeout_ms", 20000),
            max_retries=cloud.get("max_retries", 2),
            endpoint=cloud.get("endpoint", "ocr-api.cn-hangzhou.aliyuncs.com"),
        )
    if provider == "scripted":
        return ScriptedOcr.from_file(cloud["scripted_path"])
    if provider == "rapidocr":
        return LocalRapidOcr()
    raise OcrConfigError("不支持的 OCR provider: %r" % provider)
