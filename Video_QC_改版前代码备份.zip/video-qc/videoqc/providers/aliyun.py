import io

from .base import OcrFrame, OcrProvider, OcrWord


def _parse_pos(pos):
    if not pos:
        return None
    if isinstance(pos, dict):
        try:
            l, t = float(pos["left"]), float(pos["top"])
            w, h = float(pos["width"]), float(pos["height"])
            return [(l, t), (l + w, t), (l + w, t + h), (l, t + h)]
        except (KeyError, TypeError, ValueError):
            return None
    if isinstance(pos, list):
        pts = []
        for p in pos:
            if isinstance(p, dict):
                if "x" in p and "y" in p:
                    pts.append((float(p["x"]), float(p["y"])))
                elif "left" in p:
                    pts.append((float(p["left"]), float(p["top"])))
            elif isinstance(p, (list, tuple)) and len(p) >= 2:
                pts.append((float(p[0]), float(p[1])))
        if len(pts) >= 4:
            return pts[:4]
        if len(pts) == 2:
            (x0, y0), (x1, y1) = pts
            return [(x0, y0), (x1, y0), (x1, y1), (x0, y1)]
    return None


def _classify_error(exc):
    msg = ""
    code = ""
    try:
        code = str(getattr(exc, "code", "") or "")
        msg = str(getattr(exc, "message", "") or exc)
    except Exception:
        msg = str(exc)
    low = (code + " " + msg).lower()
    if "throttl" in low or "ratelimit" in low or "rate limit" in low:
        return "throttled", "调用被限流"
    if "accesskey" in low or "unauthorized" in low or "signature" in low or "forbidden" in low or "invalidaccesskey" in low:
        return "auth", "鉴权失败，请检查 AccessKey"
    if "timeout" in low or "timed out" in low:
        return "timeout", "请求超时"
    if any(k in low for k in ("invalidparameter", "parameter", "size", "format")):
        return "bad_request", "请求参数或图片不合规"
    return "server", "服务端或网络错误"


class AliyunOcr(OcrProvider):
    name = "aliyun"

    def __init__(self, access_key_id, access_key_secret, timeout_ms=20000, max_retries=2,
                 endpoint="ocr-api.cn-hangzhou.aliyuncs.com"):
        if not access_key_id or not access_key_secret:
            from .base import OcrConfigError
            raise OcrConfigError("缺少阿里云 AccessKey 凭据")
        from alibabacloud_ocr_api20210707.client import Client
        from alibabacloud_tea_openapi.models import Config
        cfg = Config(
            access_key_id=access_key_id,
            access_key_secret=access_key_secret,
            endpoint=endpoint,
        )
        self.client = Client(cfg)
        self.timeout_ms = int(timeout_ms)
        self.max_retries = int(max_retries)
        self.endpoint = endpoint

    def recognize(self, image_bytes, t_ms):
        from alibabacloud_ocr_api20210707.models import RecognizeGeneralTextAdvanceRequest
        from alibabacloud_tea_util.models import RuntimeOptions

        last_error = None
        for attempt in range(self.max_retries + 1):
            try:
                req = RecognizeGeneralTextAdvanceRequest(body=io.BytesIO(image_bytes))
                runtime = RuntimeOptions(
                    read_timeout=max(1, self.timeout_ms // 1000),
                    connect_timeout=max(1, self.timeout_ms // 1000),
                    autoretry=False,
                    max_attempts=1,
                )
                resp = self.client.recognize_general_text_advance(req, runtime)
                body = resp.body.to_map()
                data = body.get("Data") or {}
                words = []
                for wi in data.get("prism_wordsInfo") or data.get("prism_words_info") or []:
                    text = wi.get("word") or wi.get("Word") or ""
                    quad = _parse_pos(wi.get("pos") or wi.get("Pos"))
                    if not text or quad is None:
                        continue
                    words.append(OcrWord(
                        text=text,
                        quad=quad,
                        probability=float(wi.get("probability") or wi.get("Probability") or 0.0),
                    ))
                return OcrFrame(
                    ok=True,
                    words=words,
                    empty=(len(words) == 0),
                    provider_meta={"request_id": body.get("RequestId"), "endpoint": self.endpoint},
                )
            except Exception as exc:
                kind, desc = _classify_error(exc)
                last_error = "%s: %s" % (desc, exc)
                if kind in ("auth", "bad_request"):
                    break
        return OcrFrame(ok=False, error=last_error or "未知调用失败")
