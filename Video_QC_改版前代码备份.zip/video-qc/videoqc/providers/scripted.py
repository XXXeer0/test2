import json

from .base import OcrFrame, OcrProvider, OcrWord


def _bbox_to_quad(bbox):
    x0, y0, x1, y1 = bbox
    return [(x0, y0), (x1, y0), (x1, y1), (x0, y1)]


class ScriptedOcr(OcrProvider):
    name = "scripted"

    def __init__(self, mapping, tolerance_ms=500):
        self.mapping = {int(k): v for k, v in mapping.items()}
        self.times = sorted(self.mapping.keys())
        self.tolerance_ms = tolerance_ms

    @classmethod
    def from_file(cls, path):
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        mapping = {}
        for k, words in data.items():
            entry = []
            if isinstance(words, dict) and words.get("__error__"):
                mapping[int(k)] = words
                continue
            for w in words:
                if w.get("__error__"):
                    entry = w
                    break
                quad = w.get("quad")
                if quad is None:
                    quad = _bbox_to_quad(w["bbox"])
                entry.append(OcrWord(
                    text=w["text"],
                    quad=[tuple(p) for p in quad],
                    probability=float(w.get("probability", 0.99)),
                ))
            mapping[int(k)] = entry
        return cls(mapping)

    def recognize(self, image_bytes, t_ms):
        if not self.times:
            return OcrFrame(ok=True, words=[], empty=True, provider_meta={"provider": "scripted"})
        best = min(self.times, key=lambda t: abs(t - t_ms))
        if abs(best - t_ms) > self.tolerance_ms:
            return OcrFrame(ok=True, words=[], empty=True, provider_meta={"provider": "scripted", "matched": None})
        entry = self.mapping[best]
        if isinstance(entry, dict):
            return OcrFrame(ok=False, error=entry.get("__error__"), provider_meta={"provider": "scripted"})
        return OcrFrame(
            ok=True,
            words=entry,
            empty=(len(entry) == 0),
            provider_meta={"provider": "scripted", "matched": best},
        )
