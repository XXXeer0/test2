from dataclasses import dataclass, field
from typing import Optional


@dataclass
class OcrWord:
    text: str
    quad: list
    probability: float = 1.0

    @property
    def bbox(self):
        xs = [p[0] for p in self.quad]
        ys = [p[1] for p in self.quad]
        return (min(xs), min(ys), max(xs), max(ys))

    @property
    def area(self):
        x0, y0, x1, y1 = self.bbox
        return max(0.0, (x1 - x0)) * max(0.0, (y1 - y0))


@dataclass
class OcrFrame:
    ok: bool = False
    words: list = field(default_factory=list)
    error: Optional[str] = None
    empty: bool = False
    provider_meta: dict = field(default_factory=dict)


class OcrProvider:
    name = "base"

    def recognize(self, image_bytes, t_ms):
        raise NotImplementedError


class OcrConfigError(Exception):
    pass
