import html
import json
import os

RUN_STATUS_CN = {
    "needs_input": "待补输入",
    "completed": "执行完成（不代表视频合格）",
    "partial": "部分完成（存在失败或覆盖缺口）",
    "failed": "失败（无法产生可用核心结果）",
    "running": "运行中",
}
CHECK_STATUS_CN = {
    "suspected": "存在疑似候选",
    "inconclusive": "不确定",
    "no_issue_observed": "有效采样中未发现候选",
    "unavailable": "无法执行或无可用数据",
    "disabled": "未启用",
}
KIND_CN = {
    "text_mismatch": "文字差异（疑似漏字/多字/替换）",
    "alignment_uncertain": "对齐不确定或无法定位",
    "dynamic_line_count_exceeded": "动态字幕同一时刻超过一行",
    "line_count_uncertain": "行数判断不确定",
    "region_conflict": "区域归属冲突",
    "subtitle_position_out_of_band": "字幕位置超出标准字幕带",
}
SUB_CN = {
    "replace": "替换",
    "missing": "疑似漏字/漏段",
    "extra": "疑似多字",
    "large_replace": "大段差异/顺序异常候选",
    "out_of_band": "超出标准字幕带",
}


def esc(s):
    return html.escape(str(s if s is not None else ""), quote=True)


def fmt_ms(ms):
    if ms is None:
        return "无法定位"
    return "%.2fs" % (ms / 1000.0)


def _mark(text, start, end):
    text = str(text or "")
    start = int(start or 0)
    end = int(end if end is not None else len(text))
    start = max(0, min(start, len(text)))
    end = max(start, min(end, len(text)))
    if start == end:
        return esc(text)
    return "%s<mark>%s</mark>%s" % (esc(text[:start]), esc(text[start:end]), esc(text[end:]))


def _script_html(issue, script_lines=None):
    ref = issue.get("script_ref")
    if ref:
        loc = "原稿第 %d 段" % (ref.get("para_index", 0) + 1)
        sl = (script_lines or [])
        pi = ref.get("para_index")
        if sl and pi is not None and 0 <= pi < len(sl):
            loc = "原稿第 %d 条台词" % (pi + 1)
            role = (sl[pi] or {}).get("role")
            if role:
                loc += " · 角色：%s" % role
        if ref.get("para_char_start") is not None and ref.get("para_char_end") is not None:
            loc += " 第 %d–%d 字" % (ref["para_char_start"] + 1, ref["para_char_end"])
        if ref.get("cross_para"):
            loc += "（跨段）"
        if ref.get("ambiguous"):
            loc += "（重复台词，存在多个可能匹配位置，保留歧义）"
    else:
        loc = "无原稿对应位置"
    body = _mark(issue.get("script_text") or "（无）", *issue.get("script_diff") or (None, None)) \
        if issue.get("script_diff") else esc(issue.get("script_text") or "（无）")
    return loc, body


def _ocr_html(issue):
    diffs = issue.get("ocr_event_diffs") or []
    if diffs:
        parts = []
        for d in diffs:
            parts.append(_mark(d.get("text") or "", d.get("local_start"), d.get("local_end")))
        return " / ".join(parts)
    return esc(issue.get("ocr_text") or "（无）")


def render_html(result, run_dir):
    css = """
body{font-family:'PingFang SC','Microsoft YaHei',system-ui,sans-serif;margin:0;background:#f5f6f8;color:#1f2328;}
.wrap{max-width:1080px;margin:0 auto;padding:24px 16px 64px;}
h1{font-size:20px;margin:0 0 4px;} .sub{color:#6b7280;font-size:13px;margin-bottom:16px;}
.cards{display:flex;gap:12px;flex-wrap:wrap;margin-bottom:16px;}
.card{background:#fff;border:1px solid #e5e7eb;border-radius:10px;padding:14px 16px;min-width:220px;flex:1;}
.card .t{font-size:12px;color:#6b7280;margin-bottom:6px;}
.card .v{font-size:15px;font-weight:600;}
.st-suspected{color:#b45309;} .st-inconclusive{color:#92400e;} .st-no_issue_observed{color:#166534;}
.st-unavailable{color:#991b1b;} .st-completed{color:#166534;} .st-partial{color:#b45309;}
.st-failed{color:#991b1b;} .st-needs_input{color:#92400e;}
.issue{background:#fff;border:1px solid #e5e7eb;border-radius:10px;padding:16px;margin-bottom:14px;}
.issue h3{margin:0 0 8px;font-size:15px;display:flex;gap:8px;align-items:center;flex-wrap:wrap;}
.badge{font-size:12px;padding:2px 8px;border-radius:999px;border:1px solid #d1d5db;color:#374151;font-weight:400;}
.kd{font-size:12px;padding:2px 8px;border-radius:999px;background:#fef3c7;color:#92400e;}
.cols{display:flex;gap:14px;flex-wrap:wrap;}
.col{flex:1;min-width:300px;}
.col .h{font-size:12px;color:#6b7280;margin-bottom:4px;}
.txt{font-size:14px;line-height:1.7;background:#f9fafb;border:1px solid #eef0f3;border-radius:8px;padding:8px 10px;word-break:break-all;white-space:pre-wrap;}
mark{background:#fde68a;border-radius:2px;padding:0 1px;}
.evid img{max-width:100%;border:1px solid #e5e7eb;border-radius:8px;margin:4px 4px 0 0;}
.note{font-size:12px;color:#6b7280;margin-top:8px;}
table{width:100%;border-collapse:collapse;background:#fff;border:1px solid #e5e7eb;border-radius:10px;overflow:hidden;font-size:13px;}
th,td{padding:8px 10px;border-bottom:1px solid #eef0f3;text-align:left;vertical-align:top;}
th{background:#f9fafb;color:#6b7280;font-weight:500;}
.sec{font-size:16px;font-weight:600;margin:26px 0 10px;}
ul{margin:6px 0;padding-left:20px;} li{font-size:13px;color:#374151;margin:3px 0;}
.coverage{font-size:13px;color:#374151;background:#fff;border:1px solid #e5e7eb;border-radius:10px;padding:12px 14px;}
footer{margin-top:30px;font-size:12px;color:#9ca3af;border-top:1px solid #e5e7eb;padding-top:12px;line-height:1.8;}
"""

    rs = result.get("run_status", "")
    cov = result.get("coverage") or {}
    checks = result.get("checks") or {}
    issues = result.get("issues") or []
    warnings = result.get("warnings") or []
    errors = result.get("errors") or []
    info = result.get("run_info") or {}
    script_lines = result.get("script_lines") or []

    parts = []
    parts.append("<!DOCTYPE html><html lang='zh-CN'><head><meta charset='utf-8'>")
    parts.append("<title>Video QC V1 检查报告 %s</title>" % esc(result.get("run_id", "")))
    parts.append("<style>%s</style></head><body><div class='wrap'>" % css)

    parts.append("<h1>Video QC V1 检查报告</h1>")
    parts.append("<div class='sub'>运行 %s ｜ 视频：%s ｜ 原稿：%s</div>" % (
        esc(result.get("run_id", "")),
        esc(info.get("video_name", "")),
        esc(info.get("script_name", "")),
    ))

    parts.append("<div class='cards'>")
    parts.append("<div class='card'><div class='t'>运行状态</div><div class='v st-%s'>%s</div></div>" % (
        esc(rs), esc(RUN_STATUS_CN.get(rs, rs))))
    parts.append("<div class='card'><div class='t'>检查一：原稿 ↔ 动态字幕核对</div><div class='v st-%s'>%s</div></div>" % (
        esc(checks.get("script_alignment", "")),
        esc(CHECK_STATUS_CN.get(checks.get("script_alignment", ""), str(checks.get("script_alignment", ""))))))
    parts.append("<div class='card'><div class='t'>检查二：动态字幕严格单行</div><div class='v st-%s'>%s</div></div>" % (
        esc(checks.get("dynamic_single_line", "")),
        esc(CHECK_STATUS_CN.get(checks.get("dynamic_single_line", ""), str(checks.get("dynamic_single_line", ""))))))
    ps = checks.get("subtitle_position")
    if ps:
        parts.append("<div class='card'><div class='t'>检查三：字幕位置（标准字幕带）</div><div class='v st-%s'>%s</div></div>" % (
            esc(ps), esc(CHECK_STATUS_CN.get(ps, ps))))
    parts.append("<div class='card'><div class='t'>疑似/不确定问题</div><div class='v'>%d / %d</div></div>" % (
        sum(1 for i in issues if i.get("status") == "suspected"),
        sum(1 for i in issues if i.get("status") == "inconclusive"),
    ))
    parts.append("</div>")

    parts.append("<div class='sec'>检测范围与覆盖</div>")
    gap_items = "".join(
        "<li>%s – %s：%s</li>" % (fmt_ms(g.get("start_ms")), fmt_ms(g.get("end_ms")), esc(g.get("reason", "")))
        for g in (cov.get("gaps") or [])
    )
    parts.append(
        "<div class='coverage'>采样区域：下半区 %s ｜ 计划采样 %s 个 ｜ 实际处理 %s 个 ｜ "
        "OCR 成功 %s ｜ 空返回/失败 %s ｜ 采样间隔约 %s ms（时间定位误差以此为准）%s</div>" % (
            esc(cov.get("region_box", "")),
            esc(cov.get("planned_samples", "")),
            esc(cov.get("processed_samples", "")),
            esc(cov.get("successful_samples", "")),
            esc(cov.get("failed_samples", "")),
            esc(cov.get("sampling_interval_ms", "")),
            ("<ul>%s</ul>" % gap_items) if gap_items else "",
        ))

    parts.append("<div class='sec'>问题清单（%d 项）</div>" % len(issues))
    if not issues:
        parts.append("<div class='coverage'>有效处理的采样范围内未发现候选。no_issue_observed 不代表全片合格，不覆盖采样间隔内的短暂事件。</div>")
    for idx, iss in enumerate(issues, 1):
        kind = iss.get("kind", "")
        status = iss.get("status", "")
        parts.append("<div class='issue' id='issue-%d'>" % idx)
        parts.append("<h3><span class='kd'>%s</span><span class='badge st-%s'>%s</span><span class='badge'>%s</span></h3>" % (
            esc(KIND_CN.get(kind, kind)),
            esc(status),
            esc("疑似" if status == "suspected" else CHECK_STATUS_CN.get(status, status)),
            esc(SUB_CN.get(iss.get("sub", ""), iss.get("sub") or "")),
        ))
        tu = iss.get("time_uncertainty_ms")
        time_line = "%s – %s%s" % (
            fmt_ms(iss.get("start_ms")),
            fmt_ms(iss.get("end_ms")),
            ("（±约 %s ms，含未采到短暂事件的可能边界）" % esc(tu)) if tu else "",
        )
        parts.append("<div class='note'>时间：%s ｜ 动态行数：%s</div>" % (
            esc(time_line),
            esc(iss.get("observed_dynamic_lines") if iss.get("observed_dynamic_lines") is not None else "—"),
        ))
        loc, sbody = _script_html(iss, script_lines)
        parts.append("<div class='cols'><div class='col'><div class='h'>原稿（%s）</div><div class='txt'>%s</div></div>" % (esc(loc), sbody))
        parts.append("<div class='col'><div class='h'>动态字幕 OCR（按事件）</div><div class='txt'>%s</div></div></div>" % _ocr_html(iss))
        ev_imgs = iss.get("evidence") or []
        if ev_imgs:
            parts.append("<div class='evid'>")
            for evd in ev_imgs[:4]:
                if evd.get("path"):
                    parts.append("<a href='%s'><img src='%s' alt='t=%s' style='max-width:48%%'></a>" % (
                        esc(evd["path"]), esc(evd["path"]), esc(fmt_ms(evd.get("t_ms")))))
            parts.append("</div>")
        if iss.get("note"):
            parts.append("<div class='note'>%s</div>" % esc(iss["note"]))
        parts.append("</div>")

    ev_table_rows = []
    for ev in result.get("events", []) or []:
        m = ev.get("matched_script")
        if m:
            loc = "第 %d 段" % (m.get("para_index", 0) + 1)
            pi = m.get("para_index")
            if script_lines and pi is not None and 0 <= pi < len(script_lines):
                loc = "第 %d 条台词" % (pi + 1)
                role = (script_lines[pi] or {}).get("role")
                if role:
                    loc += " · %s" % role
            if m.get("para_char_start") is not None:
                loc += " 第 %d–%s 字" % (m["para_char_start"] + 1, m.get("para_char_end"))
            if m.get("ambiguous"):
                loc += "（歧义）"
        else:
            loc = "—"
        ev_table_rows.append(
            "<tr><td>%s – %s</td><td>%s</td><td>%s</td></tr>" % (
                esc(fmt_ms(ev.get("start_ms"))), esc(fmt_ms(ev.get("end_ms"))),
                esc(ev.get("text", "")), esc(loc)))
    if ev_table_rows:
        parts.append("<div class='sec'>原稿 / OCR 对照（字幕事件表）</div>")
        parts.append("<table><tr><th>时间</th><th>OCR 事件文本</th><th>原稿定位</th></tr>%s</table>" % "".join(ev_table_rows))

    if warnings:
        parts.append("<div class='sec'>警告</div><ul>%s</ul>" % "".join("<li>%s</li>" % esc(w) for w in warnings))
    if errors:
        parts.append("<div class='sec'>执行错误</div><ul>%s</ul>" % "".join("<li>%s</li>" % esc(e) for e in errors[:50]))

    parts.append("<footer>")
    parts.append("程序版本 %s ｜ schema %s ｜ 显示尺寸 %s（rotation %s°）｜ 裁剪映射：%s ｜ OCR 服务：%s ｜ 调用 %s 次（失败 %s 次）｜ 费用估算 %s 元<br>" % (
        esc(info.get("program_version", "")),
        esc(result.get("schema_version", "")),
        esc(info.get("display_size", "")),
        esc(info.get("rotation", "")),
        esc(info.get("crop_remap", "")),
        esc(info.get("ocr_provider", "")),
        esc(info.get("ocr_calls", "")),
        esc(info.get("ocr_errors", "")),
        esc(info.get("cost_estimate_yuan", "")),
    ))
    parts.append("时间依据：实际呈现时间（PTS，毫秒）；开始 %s ｜ 结束 %s。参数来源：%s。<br>" % (
        esc(info.get("started_at", "")), esc(info.get("finished_at", "")),
        esc(result.get("_param_source", "开发者建议值，待用户确认，不作为验收标准")),
    ))
    parts.append("completed 表示执行正常结束，不代表视频合格；no_issue_observed 仅覆盖有效采样；不确定与失败均在上方单独可见。</footer>")

    parts.append("</div></body></html>")
    return "".join(parts)


def write_outputs(result, run_dir):
    with open(os.path.join(run_dir, "result.json"), "w", encoding="utf-8") as f:
        json.dump(result, f, ensure_ascii=False, indent=2)
    with open(os.path.join(run_dir, "config.snapshot.json"), "w", encoding="utf-8") as f:
        json.dump(result.pop("_config_snapshot", None) or {}, f, ensure_ascii=False, indent=2)
    with open(os.path.join(run_dir, "report.html"), "w", encoding="utf-8") as f:
        f.write(render_html(result, run_dir))
