import json
import logging
import os
import time
import uuid

from . import __version__
from . import align as align_mod
from . import config as cfg_mod
from . import events as events_mod
from . import geometry as geo
from . import line_check
from . import position_check
from . classify import classify_lines
from . evidence import save_issue_evidence
from . providers import create_provider
from . report import write_outputs
from . video import crop_mapping, extract_frame, plan_samples, probe_video

logger = logging.getLogger("videoqc")


def _setup_logger(run_dir):
    logger.setLevel(logging.INFO)
    logger.handlers.clear()
    fh = logging.FileHandler(os.path.join(run_dir, "run.log"), encoding="utf-8")
    fh.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(message)s"))
    logger.addHandler(fh)


def load_script(path):
    with open(path, "rb") as f:
        raw = f.read()
    try:
        return raw.decode("utf-8-sig")
    except UnicodeDecodeError as e:
        raise cfg_mod.ConfigError(
            "原稿编码错误：仅支持 UTF-8 文本（%s）。请转换编码后重试，不静默丢弃文字" % e
        )


def _merge_gaps(entries, interval_ms):
    if not entries:
        return []
    entries = sorted(entries)
    gaps = []
    cur = {"start_ms": entries[0][0], "end_ms": entries[0][0], "reason": entries[0][1]}
    for t, reason in entries[1:]:
        if t - cur["end_ms"] <= interval_ms * 1.5 and reason == cur["reason"]:
            cur["end_ms"] = t
        else:
            gaps.append(cur)
            cur = {"start_ms": t, "end_ms": t, "reason": reason}
    gaps.append(cur)
    return gaps


def run_pipeline(cfg, script_text, out_root="output", progress=None, credentials=None, ffmpeg="ffmpeg"):
    def report(stage, detail="", pct=0):
        if progress:
            progress(stage, detail, pct)

    started_at = time.strftime("%Y-%m-%d %H:%M:%S")

    video_path = cfg.get("video_path")
    video_exists = None
    if video_path is not None:
        video_exists = os.path.isfile(video_path)
    errors, warns = cfg_mod.validate_config(cfg, video_exists=video_exists, script_text=script_text)
    if errors:
        report("validate", "；".join(errors), 0)
        return {
            "schema_version": cfg_mod.SCHEMA_VERSION,
            "run_id": None,
            "run_status": "needs_input",
            "coverage": {},
            "checks": {"script_alignment": "unavailable", "dynamic_single_line": "unavailable", "subtitle_position": "unavailable"},
            "issues": [],
            "warnings": warns,
            "errors": errors,
        }
    report("validate", "输入校验通过", 5)

    run_id = "%s-%s" % (time.strftime("%Y%m%d-%H%M%S"), uuid.uuid4().hex[:6])
    run_dir = os.path.join(out_root, run_id)
    os.makedirs(os.path.join(run_dir, "evidence"), exist_ok=True)
    os.makedirs(os.path.join(run_dir, "raw"), exist_ok=True)
    _setup_logger(run_dir)
    logger.info("run start: %s video=%s", run_id, video_path)

    try:
        meta = probe_video(video_path)
    except Exception as e:
        logger.error("probe failed: %s", e)
        result = {
            "schema_version": cfg_mod.SCHEMA_VERSION,
            "run_id": run_id,
            "run_status": "failed",
            "coverage": {},
            "checks": {"script_alignment": "unavailable", "dynamic_single_line": "unavailable", "subtitle_position": "unavailable"},
            "issues": [],
            "warnings": [],
            "errors": ["无法读取视频元数据：%s" % e],
            "run_info": {"program_version": __version__, "video_name": os.path.basename(video_path or ""), "started_at": started_at, "finished_at": time.strftime("%Y-%m-%d %H:%M:%S")},
            "_config_snapshot": cfg_mod.snapshot(cfg),
        }
        write_outputs(result, run_dir)
        return result
    report("probe", "显示尺寸 %dx%d（rotation %s°）" % (meta["display_width"], meta["display_height"], meta["rotation"]), 10)

    cloud = cfg.get("cloud") or {}
    provider = create_provider(cfg, credentials)
    sampling = cfg.get("sampling") or {}
    geo_cfg = cfg.get("geometry") or {}
    ev_cfg = cfg.get("event_grouping") or {}
    norm_cfg = cfg.get("text_normalization") or {}
    dyn_cfg = cfg.get("dynamic_subtitles") or {}
    dyn_roi = dyn_cfg.get("roi")
    expected_band = dyn_cfg.get("expected_band")
    fx = cfg.get("fixed_notice") or {}
    fixed_roi = fx.get("roi") if fx.get("present") else None

    sample_times = plan_samples(meta["duration_s"], sampling.get("base_fps", 2.0))
    interval_ms = int(round(1000.0 / float(sampling.get("base_fps", 2.0))))
    max_calls = int(cloud.get("max_calls_per_job", 5000))
    max_cost = float(cloud.get("max_cost_per_job", 50.0))
    if cloud.get("provider") == "rapidocr":
        cost_per_call = 0.0
    else:
        cost_per_call = float(cloud.get("cost_per_call", 0.0))

    sample_lines = {}
    sample_records = []
    raw_fh = open(os.path.join(run_dir, "raw", "ocr.jsonl"), "w", encoding="utf-8")
    calls = 0
    failed_calls = 0
    est_cost = 0.0
    budget_stop = False
    gap_entries = []
    error_entries = []
    ok_samples = 0
    empty_samples = 0
    planned = len(sample_times)

    try:
        for i, t_ms in enumerate(sample_times):
            if calls >= max_calls or (cost_per_call > 0 and est_cost + cost_per_call > max_cost):
                budget_stop = True
                logger.warning("budget stop at %d ms: calls=%d cost=%.2f", t_ms, calls, est_cost)
                for t2 in sample_times[i:]:
                    gap_entries.append((t2, "超出调用/费用上限，停止并保留已有结果"))
                break
            try:
                frame = extract_frame(video_path, meta, t_ms, crop_lower_half=True, ffmpeg=ffmpeg)
            except Exception as e:
                msg = "抽帧失败: %s" % e
                logger.error("t=%d ms %s", t_ms, msg)
                gap_entries.append((t_ms, "抽帧失败（视频解码错误，不得进入正常检测）"))
                error_entries.append({"t_ms": t_ms, "error": msg})
                failed_calls += 1
                calls += 1
                est_cost += cost_per_call
                sample_records.append({"t_ms": t_ms, "ok": False, "gap": True, "error": msg})
                continue

            ocr = provider.recognize(frame, t_ms)
            calls += 1
            est_cost += cost_per_call

            if not ocr.ok:
                failed_calls += 1
                reason = "OCR 调用失败（%s）" % (ocr.error or "未知错误")
                logger.error("t=%d ms %s", t_ms, reason)
                gap_entries.append((t_ms, reason))
                error_entries.append({"t_ms": t_ms, "error": ocr.error or "未知错误"})
                sample_records.append({"t_ms": t_ms, "ok": False, "gap": True, "error": ocr.error})
                raw_fh.write(json.dumps({"t_ms": t_ms, "ok": False, "error": ocr.error}, ensure_ascii=False) + "\n")
                report("sampling", "t=%.1fs OCR 失败：%s" % (t_ms / 1000.0, ocr.error), 10 + int(70 * (i + 1) / max(1, planned)))
                continue

            if ocr.empty:
                empty_samples += 1
                gap_entries.append((t_ms, "OCR 空返回（保守口径：无法确认为无字幕，记为覆盖缺口）"))
                sample_records.append({"t_ms": t_ms, "ok": True, "gap": True, "error": None})
                raw_fh.write(json.dumps({"t_ms": t_ms, "ok": True, "words": []}, ensure_ascii=False) + "\n")
                report("sampling", "t=%.1fs 空返回（覆盖缺口）" % (t_ms / 1000.0), 10 + int(70 * (i + 1) / max(1, planned)))
                continue

            ok_samples += 1
            words = geo.dedup_words(ocr.words, iou_tolerance=geo_cfg.get("duplicate_box_tolerance", 0.85))
            lines = geo.group_lines(words, v_tolerance=geo_cfg.get("same_line_tolerance", 0.5))
            cls_lines = classify_lines(lines, meta["crop_width"], meta["crop_height"], dyn_roi, fixed_roi)
            sample_lines[t_ms] = [dict(l.to_dict()) for l in cls_lines]
            rec = line_check.sample_record(t_ms, cls_lines)
            rec.update({"ok": True, "gap": False, "error": None})
            sample_records.append(rec)
            raw_fh.write(json.dumps({
                "t_ms": t_ms,
                "ok": True,
                "words": [{"text": w.text, "quad": [list(p) for p in w.quad], "probability": w.probability} for w in ocr.words],
                "meta": ocr.provider_meta,
            }, ensure_ascii=False) + "\n")
            report("sampling", "t=%.1fs" % (t_ms / 1000.0), 10 + int(70 * (i + 1) / max(1, planned)))
    finally:
        raw_fh.close()

    report("analyze", "几何归行与两项核心检查", 85)

    line_issues = line_check.build_line_issues(sample_records, interval_ms)
    pos_issues = position_check.build_position_issues(sample_lines, expected_band, interval_ms)
    valid_for_events = [r for r in sample_records if r.get("ok")]
    events = events_mod.build_events(
        valid_for_events, sample_lines,
        threshold=ev_cfg.get("text_similarity_threshold", 0.75),
        max_gap_ms=ev_cfg.get("max_gap_ms", 1200),
    )
    align_issues, align_warnings, align_status = align_mod.align(script_text, events, norm_cfg)

    unknown_total = sum(r.get("unknown_count", 0) for r in sample_records)
    if unknown_total:
        warns.append(
            "存在 %d 处未能归类的文字（背景字/角标/区域外），未参与两项检查，详见截图与 raw 数据" % unknown_total
        )

    all_issues = []
    for iss in line_issues:
        frames = iss.pop("frames", [])
        all_issues.append(iss)
        iss["frames"] = frames
    all_issues.extend(align_issues)
    all_issues.extend(pos_issues)
    all_issues.sort(key=lambda x: (x.get("start_ms") is None, x.get("start_ms") or 0))
    for n, iss in enumerate(all_issues, 1):
        iss["issue_id"] = "issue-%03d" % n
        iss["time_uncertainty_ms"] = interval_ms

    report("evidence", "生成证据截图", 92)
    for iss in all_issues:
        keys = []
        frames = iss.get("frames") or []
        if frames:
            keys = [frames[0]["t_ms"]]
            if len(frames) > 1 and frames[-1]["t_ms"] != frames[0]["t_ms"]:
                keys.append(frames[-1]["t_ms"])
        elif iss.get("start_ms") is not None:
            keys = [min(sample_lines.keys(), key=lambda t: abs(t - iss["start_ms"]))]
        ev_list = []
        for t in keys:
            items = sample_lines.get(t)
            if not items:
                continue
            name = iss["issue_id"]
            path = os.path.join("evidence", "%s.png" % name)
            zoom = os.path.join("evidence", "%s_zoom.png" % name)
            try:
                save_issue_evidence(video_path, meta, t, items,
                                    os.path.join(run_dir, path),
                                    os.path.join(run_dir, zoom), ffmpeg=ffmpeg)
                ev_list.append({"t_ms": t, "path": path})
                if os.path.isfile(os.path.join(run_dir, zoom)):
                    ev_list.append({"t_ms": t, "path": zoom})
            except Exception as e:
                logger.error("evidence failed for %s t=%d: %s", iss["issue_id"], t, e)
        iss["evidence"] = ev_list
        if not ev_list:
            warns.append("问题 %s 缺少真实截图（抽帧或解码失败），未使用伪造图片代替证据" % iss["issue_id"])

    has_gap = bool(gap_entries)
    if budget_stop:
        run_status = "partial"
    elif not sample_times:
        run_status = "failed"
    elif ok_samples == 0:
        run_status = "failed"
    elif has_gap or failed_calls > 0 or empty_samples > 0:
        run_status = "partial"
    else:
        run_status = "completed"

    line_status = line_check.derive_check_status(
        [i for i in line_issues], ok_samples > 0, has_gap
    )
    if not expected_band:
        position_status = "disabled"
    else:
        position_status = line_check.derive_check_status(pos_issues, ok_samples > 0, has_gap)

    # 剧本解析元数据：仅当与当前原稿文本段落数完全一致时传递（用户手改过即丢弃，安全降级为段号）
    script_lines = cfg.get("script_lines")
    if isinstance(script_lines, list) and script_text is not None:
        para_count = sum(1 for ln in script_text.split("\n") if ln.strip())
        if len(script_lines) != para_count:
            script_lines = None
    else:
        script_lines = None

    result = {
        "schema_version": cfg_mod.SCHEMA_VERSION,
        "run_id": run_id,
        "run_status": run_status,
        "coverage": {
            "region_box": [0, 0.5, 1, 1],
            "planned_samples": planned,
            "processed_samples": len(sample_records),
            "successful_samples": ok_samples,
            "failed_samples": failed_calls + empty_samples,
            "sampling_interval_ms": interval_ms,
            "base_fps": sampling.get("base_fps"),
            "gaps": _merge_gaps(gap_entries, interval_ms),
        },
        "checks": {
            "script_alignment": align_status,
            "dynamic_single_line": line_status,
            "subtitle_position": position_status,
        },
        "script_lines": script_lines,
        "issues": all_issues,
        "warnings": warns + align_warnings,
        "errors": [e["error"] for e in error_entries][:200] or [],
        "events": [dict(e.to_dict(), matched_script=e.matched_script) for e in events],
        "run_info": {
            "program_version": __version__,
            "video_name": os.path.basename(video_path or ""),
            "video_path": video_path,
            "script_name": os.path.basename(cfg.get("script_path") or "（粘贴文本）"),
            "display_size": "%dx%d" % (meta["display_width"], meta["display_height"]),
            "rotation": meta["rotation"],
            "duration_s": meta["duration_s"],
            "crop_remap": crop_mapping(meta)["remap"],
            "ocr_provider": provider.name,
            "ocr_calls": calls,
            "ocr_errors": failed_calls,
            "cost_estimate_yuan": round(est_cost, 2),
            "cost_note": (
                "本地推理（rapidocr），无云端调用费用"
                if cloud.get("provider") == "rapidocr"
                else "费用为按建议单价估算，实际以账单为准；单价未经用户确认"
            ),
            "started_at": started_at,
            "finished_at": time.strftime("%Y-%m-%d %H:%M:%S"),
        },
        "_param_source": cfg_mod.PARAM_SOURCE_NOTE,
        "_config_snapshot": cfg_mod.snapshot(cfg),
    }

    write_outputs(result, run_dir)
    report("write", "输出完成：%s" % run_dir, 100)
    logger.info("run done: %s status=%s", run_id, run_status)
    return result
