import difflib
from dataclasses import dataclass, field

from .classify import DYNAMIC


@dataclass
class SubtitleEvent:
    start_ms: int
    end_ms: int
    text: str
    sample_count: int = 0
    text_variants: list = field(default_factory=list)
    matched_script: dict = None

    def to_dict(self):
        return {
            "start_ms": self.start_ms,
            "end_ms": self.end_ms,
            "text": self.text,
            "sample_count": self.sample_count,
            "text_variants": self.text_variants,
        }


def _similarity(a, b):
    if not a or not b:
        return 0.0
    return difflib.SequenceMatcher(None, a, b).ratio()


def _same_event_text(prev, cur, threshold):
    if prev == cur:
        return True
    if _similarity(prev, cur) >= threshold:
        return True
    if prev and cur and (cur.startswith(prev) or prev.startswith(cur)):
        shorter, longer = (prev, cur) if len(prev) < len(cur) else (cur, prev)
        return len(shorter) / max(1, len(longer)) >= 0.5
    return False


def build_events(samples, cls_lines_by_t, threshold=0.75, max_gap_ms=1200):
    timeline = []
    for rec in samples:
        t = rec["t_ms"]
        lines = cls_lines_by_t.get(t, [])
        dyn_text = "".join(l["text"] for l in lines if l.get("cls") == DYNAMIC)
        timeline.append((t, rec, dyn_text))

    events = []
    cur = None
    prev_t = None
    prev_text = None

    def new_event(t, text):
        return SubtitleEvent(start_ms=t, end_ms=t, text=text, sample_count=1,
                             text_variants=[text])

    def absorb(ev, t, text):
        ev.end_ms = t
        ev.sample_count += 1
        if text and text not in ev.text_variants:
            ev.text_variants.append(text)

    for t, rec, dyn_text in timeline:
        sep = False
        if not rec.get("ok", True):
            sep = True
        if rec.get("gap", False):
            sep = True
        if not dyn_text:
            sep = True
        if prev_t is not None and (t - prev_t) > max_gap_ms:
            sep = True

        if sep:
            cur = None
            if dyn_text and rec.get("ok", True) and not rec.get("gap", False):
                cur = new_event(t, dyn_text)
                events.append(cur)
            prev_t = t
            prev_text = dyn_text or None
            continue

        if cur is None:
            cur = new_event(t, dyn_text)
            events.append(cur)
        else:
            if prev_text and not _same_event_text(prev_text, dyn_text, threshold):
                cur = new_event(t, dyn_text)
                events.append(cur)
            else:
                absorb(cur, t, dyn_text)
        prev_t = t
        prev_text = dyn_text or None

    for ev in events:
        counts = {}
        for v in ev.text_variants:
            counts[v] = counts.get(v, 0) + 1
        best = None
        best_key = (-1, -1)
        for v, c in counts.items():
            key = (c, len(v))
            if key > best_key:
                best_key = key
                best = v
        ev.text = best or ev.text
    return events
