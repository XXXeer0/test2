"""字幕位置检测：动态字幕是否落在标准字幕带内。

设计原则（对应问题分析与改进方案.txt 改进 1）：
- 标准带来自剪映 9:16 同源字幕位（x:0, y:-478）换算：画面中心原点、
  1920 高 -> 字幕中心距顶 1438/1920 ≈ 0.749；带默认 [0.02, 0.68, 0.98, 0.85]；
- 仅检查被认作动态字幕（dynamic）的行，超带写入报告（疑似项）；
- 带外花字/滚动条等本来就不会被认作 dynamic（unknown 有独立警告），不在此重复报告；
- 只读采样结果做检测，不改几何归行/分类/对齐底层。
"""

from .classify import DYNAMIC
from .config import roi_cover_ratio

KIND_POSITION = "subtitle_position_out_of_band"

# 行框允许 10% 面积出带（与分类收紧阈值呼应，避免边缘像素级误报）
COVER_THRESHOLD = 0.9


def build_position_issues(sample_lines_by_t, band, interval_ms, cover_threshold=COVER_THRESHOLD):
    """逐帧检查 dynamic 行与标准带的交集比，连续帧合并为一个问题。"""
    if not band:
        return []
    issues = []
    active = None
    last_t = None

    for t in sorted(sample_lines_by_t.keys()):
        violations = []
        for l in sample_lines_by_t.get(t) or []:
            if l.get("cls") != DYNAMIC:
                continue
            box = l.get("bbox_full_norm")
            if not box:
                continue
            cover = roi_cover_ratio(band, box)
            if cover < cover_threshold:
                violations.append({
                    "text": l.get("text") or "",
                    "cover": round(cover, 3),
                    "bbox": [round(v, 4) for v in box],
                })
        if violations:
            if active is not None and t - last_t > interval_ms * 1.5:
                active = None
            if active is None:
                active = {
                    "kind": KIND_POSITION,
                    "status": "suspected",
                    "sub": "out_of_band",
                    "start_ms": t,
                    "end_ms": t,
                    "frames": [],
                }
                issues.append(active)
            active["end_ms"] = t
            active["frames"].append({"t_ms": t, "violations": violations})
            last_t = t
        else:
            if active is not None and t - last_t > interval_ms * 1.5:
                active = None

    for iss in issues:
        texts = []
        for f in iss["frames"]:
            for v in f["violations"]:
                if v["text"] not in texts:
                    texts.append(v["text"])
        iss["ocr_text"] = " / ".join(texts)[:300]
        worst = min((v["cover"] for f in iss["frames"] for v in f["violations"]), default=None)
        iss["band"] = [round(v, 4) for v in band]
        iss["min_cover"] = worst
        iss["note"] = (
            "该时段字幕未完全落在标准字幕带 %s 内（最低交叠 %.0f%%，阈值 %.0f%%）。"
            "可能是字幕位置偏移，也可能是区域边缘的其他文字，请结合截图人工确认"
            % (iss["band"], (worst if worst is not None else 0) * 100, cover_threshold * 100)
        )
    return issues
