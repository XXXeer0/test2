import json
import math
import subprocess


class VideoError(Exception):
    pass


def _run(cmd, timeout=60):
    try:
        proc = subprocess.run(cmd, capture_output=True, timeout=timeout)
    except FileNotFoundError:
        raise VideoError("未找到 ffmpeg/ffprobe，请先安装并加入 PATH")
    except subprocess.TimeoutExpired:
        raise VideoError("ffmpeg/ffprobe 执行超时")
    if proc.returncode != 0:
        msg = proc.stderr.decode("utf-8", "replace").strip()
        raise VideoError("命令失败: %s" % (msg[-400:] if msg else proc.returncode))
    return proc


def probe_video(path, ffprobe="ffprobe"):
    proc = _run([ffprobe, "-v", "quiet", "-print_format", "json", "-show_format", "-show_streams", path])
    try:
        meta = json.loads(proc.stdout.decode("utf-8", "replace"))
    except json.JSONDecodeError:
        raise VideoError("ffprobe 输出无法解析")

    vstream = None
    for s in meta.get("streams", []):
        if s.get("codec_type") == "video":
            vstream = s
            break
    if vstream is None:
        raise VideoError("未找到视频流（无画面），无法进行两项核心检查")

    rotation = 0.0
    for sd in vstream.get("side_data_list") or []:
        if "rotation" in sd:
            rotation = float(sd["rotation"])
            break
    if rotation == 0.0:
        tag = (vstream.get("tags") or {}).get("rotate")
        if tag is not None:
            try:
                rotation = float(tag)
            except ValueError:
                rotation = 0.0

    dar = 1.0
    sar = vstream.get("sample_aspect_ratio")
    if sar and ":" in str(sar):
        try:
            num, den = str(sar).split(":")
            num, den = float(num), float(den)
            if num > 0 and den > 0:
                dar = num / den
        except ValueError:
            dar = 1.0

    w = int(vstream.get("width") or 0)
    h = int(vstream.get("height") or 0)
    if w <= 0 or h <= 0:
        raise VideoError("视频尺寸信息无效")

    duration = None
    for src in (vstream.get("duration"), (meta.get("format") or {}).get("duration")):
        try:
            if src is not None:
                duration = float(src)
                break
        except (TypeError, ValueError):
            continue

    start_time = 0.0
    try:
        st = vstream.get("start_time")
        if st is not None:
            start_time = max(0.0, float(st))
    except (TypeError, ValueError):
        start_time = 0.0

    swap = abs(rotation) % 180 == 90
    pw, ph = (h, w) if swap else (w, h)
    display_w = int(round(pw * dar))
    display_h = ph

    return {
        "width": w,
        "height": h,
        "rotation": rotation,
        "pixel_aspect": dar,
        "duration_s": duration,
        "start_time_s": start_time,
        "display_width": display_w,
        "display_height": display_h,
        "crop_width": display_w,
        "crop_height": display_h // 2,
        "has_audio": any(s.get("codec_type") == "audio" for s in meta.get("streams", [])),
    }


def vf_chain(meta, crop_lower_half=True):
    parts = []
    rot = int(round(abs(meta["rotation"]))) % 360
    if rot == 90:
        parts.append("transpose=2")
    elif rot == 180:
        parts.append("hflip,vflip")
    elif rot == 270:
        parts.append("transpose=1")
    dw, dh = meta["display_width"], meta["display_height"]
    if dw != meta["width"] or dh != meta["height"] or meta["pixel_aspect"] != 1.0:
        parts.append("scale=%d:%d,setsar=1" % (dw, dh))
    if crop_lower_half:
        parts.append("crop=%d:%d:0:%d" % (dw, dh // 2, dh // 2))
    return ",".join(parts) if parts else "null"


def extract_frame(path, meta, t_ms, crop_lower_half=True, ffmpeg="ffmpeg"):
    t = max(0, t_ms) / 1000.0
    vf = vf_chain(meta, crop_lower_half)
    cmd = [
        ffmpeg, "-hide_banner", "-loglevel", "error", "-noautorotate",
        "-ss", "%.3f" % t, "-i", path,
        "-frames:v", "1", "-vf", vf,
        "-f", "image2", "-c:v", "mjpeg", "-q:v", "2", "pipe:1",
    ]
    proc = _run(cmd, timeout=90)
    if not proc.stdout:
        raise VideoError("抽帧结果为空（t=%d ms）" % t_ms)
    return proc.stdout


def crop_to_full_norm(xn, yn):
    return xn, 0.5 + yn * 0.5


def plan_samples(duration_s, base_fps):
    if not duration_s or duration_s <= 0:
        return []
    step_ms = 1000.0 / float(base_fps)
    dur_ms = duration_s * 1000.0
    count = int(math.floor(duration_s * float(base_fps) + 1e-6)) + 1
    out = []
    for i in range(count):
        t_ms = int(round(i * step_ms))
        if t_ms < dur_ms - 1:
            out.append(t_ms)
    return out


def crop_mapping(meta):
    return {
        "crop_region_norm": [0, 0.5, 1, 1],
        "crop_size_px": [meta["crop_width"], meta["crop_height"]],
        "display_size_px": [meta["display_width"], meta["display_height"]],
        "remap": "crop_norm (x,y) -> full_norm (x, 0.5 + y*0.5)",
        "rounding": "display size rounded half-up; crop height = floor(display_height/2)",
    }
