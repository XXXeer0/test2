import copy
import json

SCHEMA_VERSION = "lean-1.0"
LOWER_HALF = [0, 0.5, 1, 1]

# 标准字幕带（归一化 [x0, y0, x1, y1]）。
# 来源：剪映 9:16 同源视频默认字幕位 x:0, y:-478（画面中心为原点、1920 高）：
#   x=0   -> 水平居中（0.5）
#   y=-478 -> 字幕中心位于中心下方 478px，即距顶 (960+478)/1920 ≈ 0.749
# 与用户实测圈选 ROI（y 0.704~0.806，中心 0.755）吻合；带四周留余量。
# 配置文件中 expected_band 为 null 时关闭位置检测（受控回归样本默认不受影响）。
DEFAULT_SUBTITLE_BAND = [0.02, 0.68, 0.98, 0.85]

RECOMMENDED = {
    "capture": {"region_box": [0, 0.5, 1, 1]},
    "text_normalization": {"ignore_whitespace": False, "ignore_punctuation": False},
    "sampling": {"base_fps": 2.0},
    "geometry": {"duplicate_box_tolerance": 0.85, "same_line_tolerance": 0.5},
    "event_grouping": {"text_similarity_threshold": 0.75, "max_gap_ms": 1200},
    "cloud": {
        "ocr_enabled": True,
        "provider": None,
        "upload_confirmed": False,
        "max_calls_per_job": 5000,
        "max_cost_per_job": 50.0,
        "cost_per_call": 0.01,
        "timeout_ms": 20000,
        "max_retries": 2,
    },
}

PARAM_SOURCE_NOTE = (
    "未确认数值均为开发者建议值（developer-recommended），经小样验证使用，"
    "不作为用户已确认的验收标准"
)


class ConfigError(Exception):
    pass


def deep_merge(base, override):
    out = copy.deepcopy(base)
    for k, v in (override or {}).items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = deep_merge(out[k], v)
        else:
            out[k] = v
    return out


def load_config(path):
    with open(path, "r", encoding="utf-8") as f:
        user = json.load(f)
    cfg = deep_merge(copy.deepcopy(RECOMMENDED), user)
    cfg["schema_version"] = user.get("schema_version", SCHEMA_VERSION)
    return cfg


def roi_valid(roi):
    if not isinstance(roi, (list, tuple)) or len(roi) != 4:
        return False
    if not all(isinstance(v, (int, float)) and not isinstance(v, bool) for v in roi):
        return False
    x0, y0, x1, y1 = roi
    return x0 >= 0 and y0 >= 0 and x1 <= 1 and y1 <= 1 and (x1 - x0) > 1e-9 and (y1 - y0) > 1e-9


def roi_in_lower_half(roi):
    return roi[1] >= 0.5 - 1e-9 and roi[3] <= 1.0 + 1e-9


def roi_cover_ratio(roi, box):
    x0 = max(roi[0], box[0])
    y0 = max(roi[1], box[1])
    x1 = min(roi[2], box[2])
    y1 = min(roi[3], box[3])
    if x1 <= x0 or y1 <= y0:
        return 0.0
    inter = (x1 - x0) * (y1 - y0)
    area = max((box[2] - box[0]) * (box[3] - box[1]), 1e-12)
    return inter / area


def roi_intersection_ratio(a, b):
    x0 = max(a[0], b[0])
    y0 = max(a[1], b[1])
    x1 = min(a[2], b[2])
    y1 = min(a[3], b[3])
    if x1 <= x0 or y1 <= y0:
        return 0.0
    inter = (x1 - x0) * (y1 - y0)
    aa = (a[2] - a[0]) * (a[3] - a[1])
    ba = (b[2] - b[0]) * (b[3] - b[1])
    return inter / min(aa, ba) if min(aa, ba) > 0 else 0.0


def _num(v):
    return isinstance(v, (int, float)) and not isinstance(v, bool)


def validate_config(cfg, video_exists=None, script_text=None):
    errors = []
    warnings = []

    if cfg.get("schema_version") != SCHEMA_VERSION:
        errors.append("schema_version 必须为 lean-1.0")

    cap = cfg.get("capture") or {}
    if cap.get("region_box") != LOWER_HALF:
        errors.append("capture.region_box 本版本固定为 [0, 0.5, 1, 1]（下半区）")

    dyn = cfg.get("dynamic_subtitles") or {}
    if dyn.get("max_lines") != 1:
        errors.append("本版本要求 dynamic_subtitles.max_lines = 1，禁止放宽行数")
    roi = dyn.get("roi")
    if not roi_valid(roi):
        errors.append("动态字幕 ROI 必填，格式 [x0,y0,x1,y1]，归一化坐标且有正面积")
    elif not roi_in_lower_half(roi):
        errors.append("动态 ROI 必须完整位于显示画面下半区（y ≥ 0.5），请先修正配置")
    band = dyn.get("expected_band")
    if band is not None:
        if not roi_valid(band):
            errors.append("字幕位置带 expected_band 格式应为 [x0,y0,x1,y1]（0~1 且有正面积），或为 null 关闭位置检测")
        elif not roi_in_lower_half(band):
            errors.append("字幕位置带必须完整位于画面下半区（y ≥ 0.5）")
    sl = cfg.get("script_lines")
    if sl is not None and not isinstance(sl, list):
        errors.append("script_lines 应为台词元数据列表（由界面剧本解析生成），手工配置请省略")

    fx = cfg.get("fixed_notice") or {}
    present = fx.get("present")
    if present:
        froi = fx.get("roi")
        if not roi_valid(froi):
            errors.append("声明存在固定提示时 fixed_notice.roi 必填")
        elif not roi_in_lower_half(froi):
            errors.append("固定提示 ROI 必须完整位于下半区")
        if fx.get("exclude_from_dynamic_line_count") is not True:
            errors.append("fixed_notice.exclude_from_dynamic_line_count 必须为 true")
        if fx.get("exclude_from_script_alignment") is not True:
            errors.append("fixed_notice.exclude_from_script_alignment 必须为 true")
        if roi_valid(roi) and roi_valid(froi):
            r = roi_intersection_ratio(roi, froi)
            if r > 0:
                warnings.append(
                    "动态 ROI 与固定 ROI 相交（重叠比 %.2f），重叠文字将按 region_conflict 记录，不做遮盖" % r
                )
    else:
        if fx.get("roi"):
            errors.append("无固定提示时应为 present=false 且 roi=null，不得以声明绕过")

    fps = (cfg.get("sampling") or {}).get("base_fps")
    if not (_num(fps) and fps > 0):
        errors.append("sampling.base_fps 必须为正数")

    geo = cfg.get("geometry") or {}
    for k in ("duplicate_box_tolerance", "same_line_tolerance"):
        v = geo.get(k)
        if not (_num(v) and 0 < v <= 1):
            errors.append("geometry.%s 须为 (0,1] 内数值" % k)
    ev = cfg.get("event_grouping") or {}
    v = ev.get("text_similarity_threshold")
    if not (_num(v) and 0 < v <= 1):
        errors.append("event_grouping.text_similarity_threshold 须为 (0,1] 内数值")
    v = ev.get("max_gap_ms")
    if not (_num(v) and v >= 0):
        errors.append("event_grouping.max_gap_ms 须为非负毫秒数")

    cloud = cfg.get("cloud") or {}
    if cloud.get("ocr_enabled"):
        provider = cloud.get("provider")
        if not provider:
            errors.append("cloud.provider 必填")
        elif provider not in ("aliyun", "scripted", "rapidocr"):
            errors.append("cloud.provider 仅支持 rapidocr / aliyun / scripted")
        if provider == "scripted" and not cloud.get("scripted_path"):
            errors.append("scripted OCR 需要提供 scripted_path")
        if provider == "aliyun":
            for k in ("max_calls_per_job", "max_cost_per_job", "timeout_ms"):
                v = cloud.get(k)
                if not (_num(v) and v > 0):
                    errors.append("cloud.%s 必须为正数" % k)
            mr = cloud.get("max_retries")
            if not (isinstance(mr, int) and not isinstance(mr, bool) and mr >= 0):
                errors.append("cloud.max_retries 必须为非负整数")
            if cloud.get("upload_confirmed") is not True:
                errors.append("cloud.upload_confirmed 必须为 true（已确认仅上传下半区裁剪图）")
        if provider == "rapidocr":
            v = cloud.get("max_calls_per_job")
            if not (_num(v) and v > 0):
                errors.append("cloud.max_calls_per_job 必须为正数")

    if video_exists is False:
        errors.append("视频文件不存在")
    if script_text is not None and not script_text.strip():
        errors.append("原稿为空，请补齐台词内容")

    return errors, warnings


def strip_secrets(cfg):
    snap = copy.deepcopy(cfg)
    cloud = snap.get("cloud") or {}
    for k in ("access_key_id", "access_key_secret", "api_key"):
        cloud.pop(k, None)
    snap.pop("script_text", None)
    return snap


def snapshot(cfg, extra=None):
    snap = strip_secrets(cfg)
    snap["_param_source"] = PARAM_SOURCE_NOTE
    if extra:
        snap.update(extra)
    return snap
