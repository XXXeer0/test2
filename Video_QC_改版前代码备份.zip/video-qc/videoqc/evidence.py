import io

from PIL import Image, ImageDraw, ImageFont

from . import video as vmod

CLS_COLORS = {
    "dynamic": (37, 99, 235),
    "fixed": (217, 119, 6),
    "conflict": (220, 38, 38),
    "unknown": (100, 116, 139),
}
CLS_LABELS_CN = {"dynamic": "动态", "fixed": "固定", "conflict": "冲突", "unknown": "不明"}
CLS_LABELS_EN = {"dynamic": "dyn", "fixed": "fix", "conflict": "cfl", "unknown": "unk"}

_font_cache = None


def _font():
    global _font_cache
    if _font_cache is None:
        loaded = None
        for p in (
            r"C:\Windows\Fonts\msyh.ttc",
            r"C:\Windows\Fonts\simhei.ttf",
            "/System/Library/Fonts/PingFang.ttc",
            "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
        ):
            try:
                loaded = ImageFont.truetype(p, 20)
                break
            except OSError:
                continue
        _font_cache = (loaded, loaded is not None)
    return _font_cache


def render_full_frame(video_path, meta, t_ms, ffmpeg="ffmpeg"):
    data = vmod.extract_frame(video_path, meta, t_ms, crop_lower_half=False, ffmpeg=ffmpeg)
    return Image.open(io.BytesIO(data)).convert("RGB")


def annotate(img, items):
    draw = ImageDraw.Draw(img)
    W, H = img.size
    font, has_cjk = _font()
    labels = CLS_LABELS_CN if has_cjk else CLS_LABELS_EN
    for it in items:
        x0, y0, x1, y1 = it["bbox_full_norm"]
        px = (x0 * W, y0 * H, x1 * W, y1 * H)
        color = CLS_COLORS.get(it.get("cls", "unknown"), CLS_COLORS["unknown"])
        draw.rectangle(px, outline=color, width=4)
        text = it.get("text") or ""
        label = "%s: %s" % (labels.get(it.get("cls", "unknown"), "?"), text[:14])
        try:
            draw.text((px[0] + 4, max(0.0, px[1] - 24)), label, fill=color, font=font)
        except Exception:
            pass
    return img


def annotate_rois(img, dyn_roi, fixed_roi):
    draw = ImageDraw.Draw(img)
    W, H = img.size
    font, has_cjk = _font()
    if dyn_roi:
        px = (dyn_roi[0] * W, dyn_roi[1] * H, dyn_roi[2] * W, dyn_roi[3] * H)
        draw.rectangle(px, outline=(37, 99, 235), width=4)
    if fixed_roi:
        px = (fixed_roi[0] * W, fixed_roi[1] * H, fixed_roi[2] * W, fixed_roi[3] * H)
        draw.rectangle(px, outline=(217, 119, 6), width=4)
    return img


def _zoom_bounds(items, focus_cls):
    xs0, ys0, xs1, ys1 = [], [], [], []
    for it in items:
        if it.get("cls") not in focus_cls:
            continue
        b = it["bbox_full_norm"]
        xs0.append(b[0])
        ys0.append(b[1])
        xs1.append(b[2])
        ys1.append(b[3])
    if not xs0:
        return None
    x0, y0, x1, y1 = min(xs0), min(ys0), max(xs1), max(ys1)
    pad_x = max(0.05, (x1 - x0) * 0.25)
    pad_y = max(0.03, (y1 - y0) * 0.5)
    return [max(0.0, x0 - pad_x), max(0.5, y0 - pad_y), min(1.0, x1 + pad_x), min(1.0, y1 + pad_y)]


def save_issue_evidence(video_path, meta, t_ms, items, out_path, zoom_path=None, ffmpeg="ffmpeg"):
    img = render_full_frame(video_path, meta, t_ms, ffmpeg=ffmpeg)
    annotate(img, items)
    img.save(out_path)
    if zoom_path:
        bounds = _zoom_bounds(items, ("dynamic", "conflict"))
        if bounds:
            W, H = img.size
            crop = img.crop((
                int(bounds[0] * W),
                int(bounds[1] * H),
                int(bounds[2] * W),
                int(bounds[3] * H),
            ))
            crop.save(zoom_path)
    return out_path
