from dataclasses import dataclass, field


def iou(a, b):
    x0 = max(a[0], b[0])
    y0 = max(a[1], b[1])
    x1 = min(a[2], b[2])
    y1 = min(a[3], b[3])
    if x1 <= x0 or y1 <= y0:
        return 0.0
    inter = (x1 - x0) * (y1 - y0)
    aa = max(1e-9, (a[2] - a[0]) * (a[3] - a[1]))
    ba = max(1e-9, (b[2] - b[0]) * (b[3] - b[1]))
    return inter / min(aa, ba)


def center_dist(a, b):
    ax = (a[0] + a[2]) / 2.0
    ay = (a[1] + a[3]) / 2.0
    bx = (b[0] + b[2]) / 2.0
    by = (b[1] + b[3]) / 2.0
    return ((ax - bx) ** 2 + (ay - by) ** 2) ** 0.5


def dedup_words(words, iou_tolerance=0.85):
    items = sorted(words, key=lambda w: -w.area)
    kept = []
    for w in items:
        is_dup = False
        for k in kept:
            if w.text.strip() == k.text.strip():
                v = iou(w.bbox, k.bbox)
                if v >= iou_tolerance:
                    is_dup = True
                    break
                hmax = max(w.bbox[3] - w.bbox[1], k.bbox[3] - k.bbox[1])
                if v >= 0.35 and center_dist(w.bbox, k.bbox) <= 0.3 * max(1e-9, hmax):
                    is_dup = True
                    break
        if not is_dup:
            kept.append(w)
    return kept


def v_overlap_ratio(a, b):
    y0 = max(a[1], b[1])
    y1 = min(a[3], b[3])
    if y1 <= y0:
        return 0.0
    ha = max(1e-9, a[3] - a[1])
    hb = max(1e-9, b[3] - b[1])
    return (y1 - y0) / min(ha, hb)


@dataclass
class TextLine:
    text: str
    bbox: tuple
    boxes: list = field(default_factory=list)


def group_lines(words, v_tolerance=0.5):
    ws = sorted(words, key=lambda w: (w.bbox[1], w.bbox[0]))
    assigned = [False] * len(ws)
    lines = []
    for i, w in enumerate(ws):
        if assigned[i]:
            continue
        group = [i]
        assigned[i] = True
        changed = True
        while changed:
            changed = False
            for j in range(len(ws)):
                if assigned[j]:
                    continue
                if any(v_overlap_ratio(ws[g].bbox, ws[j].bbox) >= v_tolerance for g in group):
                    group.append(j)
                    assigned[j] = True
                    changed = True
        boxes = sorted([ws[g] for g in group], key=lambda b: b.bbox[0])
        x0 = min(b.bbox[0] for b in boxes)
        y0 = min(b.bbox[1] for b in boxes)
        x1 = max(b.bbox[2] for b in boxes)
        y1 = max(b.bbox[3] for b in boxes)
        lines.append(TextLine(
            text="".join(b.text for b in boxes),
            bbox=(x0, y0, x1, y1),
            boxes=boxes,
        ))
    lines.sort(key=lambda l: (l.bbox[1], l.bbox[0]))
    return lines
