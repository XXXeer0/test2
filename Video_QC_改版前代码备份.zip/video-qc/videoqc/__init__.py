__version__ = "0.1.0"
SCHEMA_VERSION = "lean-1.0"
