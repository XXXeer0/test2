import difflib

PUNCTUATION = set(
    "，。！？；：、·…—～“”‘’《》〈〉【】〔〕"
    ",.!?;:\"'`()<>[]{}@#$%^&*_=+|/\\ \t　"
)
BIG_BLOCK_CHARS = 40


class ScriptPara:
    def __init__(self, index, start, end, text):
        self.index = index
        self.start = start
        self.end = end
        self.text = text


def parse_script(text):
    text = text.replace("\r\n", "\n").replace("\r", "\n")
    paras = []
    pos = 0
    for line in text.split("\n"):
        if line.strip():
            paras.append(ScriptPara(len(paras), pos, pos + len(line), line))
        pos += len(line) + 1
    return text, paras


def normalize_keep_map(s, ignore_ws=False, ignore_punct=False):
    chars = []
    mapping = []
    for i, ch in enumerate(s):
        if ignore_ws and (ch.isspace() or ch == "\u3000"):
            continue
        if ignore_punct and ch in PUNCTUATION:
            continue
        chars.append(ch)
        mapping.append(i)
    return "".join(chars), mapping


def build_norm_script(paras, ignore_ws, ignore_punct):
    parts = []
    locators = []
    for p in paras:
        seg, seg_map = normalize_keep_map(p.text, ignore_ws, ignore_punct)
        parts.append(seg)
        for oi in seg_map:
            locators.append((p.index, oi))
    return "".join(parts), locators


def _ref_for(locators, paras, a_start, a_end):
    if a_end <= a_start or a_start >= len(locators):
        return None
    p0, off0 = locators[a_start]
    p1, off1 = locators[min(a_end, len(locators)) - 1]
    if p0 == p1:
        return {
            "para_index": p0,
            "para_char_start": off0,
            "para_char_end": off1 + 1,
            "cross_para": False,
            "ambiguous": False,
        }
    return {
        "para_index": p0,
        "para_char_start": off0,
        "para_char_end": None,
        "cross_para": True,
        "ambiguous": False,
    }


def _script_slice(paras, locators, a1, a2):
    if a2 <= a1:
        return "", None
    p0, off0 = locators[a1]
    p1, off1 = locators[min(a2, len(locators)) - 1]
    if p0 == p1:
        para = paras[p0]
        return para.text[off0:off1 + 1], (off0, off1 + 1)
    texts = [paras[i].text for i in range(p0, p1 + 1)]
    return " / ".join(texts), None


def align(script_text, events, norm_cfg):
    ignore_ws = bool(norm_cfg.get("ignore_whitespace"))
    ignore_punct = bool(norm_cfg.get("ignore_punctuation"))

    issues = []
    warnings = []

    if not events:
        warnings.append("全片无可用动态字幕，无法完成原稿核对；不输出原稿全部漏字")
        return issues, warnings, "unavailable"

    script_text, paras = parse_script(script_text)
    if not paras:
        warnings.append("原稿无有效非空段落，无法完成核对")
        return issues, warnings, "unavailable"
    ns, locators = build_norm_script(paras, ignore_ws, ignore_punct)

    spans = []
    parts = []
    pos = 0
    for ev in events:
        ne, me = normalize_keep_map(ev.text, ignore_ws, ignore_punct)
        spans.append({"start": pos, "end": pos + len(ne), "event": ev, "norm": ne, "map": me})
        parts.append(ne)
        pos += len(ne)
    no = "".join(parts)

    if not no:
        warnings.append("事件文本规范化后为空，无法完成原稿核对")
        return issues, warnings, "unavailable"

    def events_in(b1, b2):
        return [s for s in spans if s["end"] > b1 and s["start"] < b2]

    sm = difflib.SequenceMatcher(None, ns, no, autojunk=False)
    opcodes = sm.get_opcodes()
    matched_events = []

    for tag, a1, a2, b1, b2 in opcodes:
        if tag == "equal":
            for s in events_in(b1, b2):
                ov_s = max(b1, s["start"])
                ov_e = min(b2, s["end"])
                if ov_e <= ov_s:
                    continue
                a_range = (a1 + (ov_s - b1), a1 + (ov_e - b1))
                ref = _ref_for(locators, paras, a_range[0], a_range[1])
                if ref is None:
                    continue
                ref["ambiguous"] = ns.count(s["norm"]) > 1
                s["event"].matched_script = ref
                matched_events.append(s)
            continue

        evs = events_in(b1, b2)
        ev_texts = " / ".join(s["event"].text for s in evs)

        if tag == "replace":
            big = (a2 - a1) > BIG_BLOCK_CHARS or (b2 - b1) > BIG_BLOCK_CHARS
            if big:
                issues.append({
                    "kind": "alignment_uncertain",
                    "status": "inconclusive",
                    "sub": "large_replace",
                    "start_ms": min((s["event"].start_ms for s in evs), default=None),
                    "end_ms": max((s["event"].end_ms for s in evs), default=None),
                    "script_ref": _ref_for(locators, paras, a1, a2),
                    "script_text": _script_slice(paras, locators, a1, a2)[0],
                    "ocr_text": ev_texts,
                    "ocr_event_diffs": [
                        {"text": s["event"].text, "local_start": 0, "local_end": len(s["event"].text)}
                        for s in evs
                    ],
                    "script_diff": None,
                    "note": "两侧文本均较长，可能存在顺序变化或无法对齐，未逐字输出差异，需人工核对",
                })
                continue
            s_text, s_range = _script_slice(paras, locators, a1, a2)
            ev_diffs = []
            for s in evs:
                lo_s = max(b1, s["start"]) - s["start"]
                lo_e = min(b2, s["end"]) - s["start"]
                os_ = s["map"][lo_s] if lo_s < len(s["map"]) else len(s["event"].text)
                oe_ = (s["map"][lo_e - 1] + 1) if lo_e > lo_s else os_
                ev_diffs.append({"text": s["event"].text, "local_start": os_, "local_end": oe_})
            issues.append({
                "kind": "text_mismatch",
                "status": "suspected",
                "sub": "replace",
                "start_ms": min((s["event"].start_ms for s in evs), default=None),
                "end_ms": max((s["event"].end_ms for s in evs), default=None),
                "script_ref": _ref_for(locators, paras, a1, a2),
                "script_text": s_text,
                "ocr_text": ev_texts,
                "ocr_event_diffs": ev_diffs,
                "script_diff": s_range,
                "note": "OCR 误识别也可能导致该差异；本结果为疑似项，需人工复核",
            })

        elif tag == "delete":
            prev_ms = None
            next_ms = None
            for s in matched_events:
                if s["end"] <= b1:
                    prev_ms = s["event"].end_ms
                if s["start"] >= b2 and next_ms is None:
                    next_ms = s["event"].start_ms
            for s in spans:
                if s["start"] >= b2 and next_ms is None:
                    next_ms = s["event"].start_ms
            has_range = prev_ms is not None or next_ms is not None
            s_text, _ = _script_slice(paras, locators, a1, a2)
            big = (a2 - a1) > BIG_BLOCK_CHARS
            if not has_range:
                issues.append({
                    "kind": "alignment_uncertain",
                    "status": "inconclusive",
                    "sub": "missing",
                    "start_ms": None,
                    "end_ms": None,
                    "script_ref": _ref_for(locators, paras, a1, a2),
                    "script_text": s_text,
                    "ocr_text": "",
                    "ocr_event_diffs": [],
                    "script_diff": None,
                    "note": "原稿该段未识别到对应字幕，且无相邻已对齐片段可推定时间（无法定位）；OCR 未识别或字幕缺失均可能，不能据此断定原片漏字幕",
                })
            elif big:
                issues.append({
                    "kind": "alignment_uncertain",
                    "status": "inconclusive",
                    "sub": "missing",
                    "start_ms": prev_ms,
                    "end_ms": next_ms,
                    "script_ref": _ref_for(locators, paras, a1, a2),
                    "script_text": s_text,
                    "ocr_text": "",
                    "ocr_event_diffs": [],
                    "script_diff": None,
                    "note": "疑似较大段落未出现在字幕中（或为顺序变化/未识别），时间仅为相邻已对齐片段之间的范围；OCR 未识别或字幕缺失均可能，不能据此断定原片漏字幕",
                })
            else:
                issues.append({
                    "kind": "text_mismatch",
                    "status": "inconclusive",
                    "sub": "missing",
                    "start_ms": prev_ms,
                    "end_ms": next_ms,
                    "script_ref": _ref_for(locators, paras, a1, a2),
                    "script_text": s_text,
                    "ocr_text": "",
                    "ocr_event_diffs": [],
                    "script_diff": None,
                    "note": "疑似漏字/漏段；OCR 未识别或字幕缺失均可能，时间仅为相邻已对齐片段之间的范围，不能据此断定原片漏字幕",
                })

        elif tag == "insert":
            issues.append({
                "kind": "text_mismatch",
                "status": "suspected",
                "sub": "extra",
                "start_ms": min((s["event"].start_ms for s in evs), default=None),
                "end_ms": max((s["event"].end_ms for s in evs), default=None),
                "script_ref": None,
                "script_text": "",
                "ocr_text": ev_texts,
                "ocr_event_diffs": [
                    {"text": s["event"].text, "local_start": 0, "local_end": len(s["event"].text)}
                    for s in evs
                ],
                "script_diff": None,
                "note": "OCR 误识别也可能导致该差异（疑似多字）；本结果为疑似项，需人工复核",
            })

    for s in spans:
        ev = s["event"]
        if ev.matched_script and ev.matched_script.get("ambiguous"):
            warnings.append(
                "重复台词存在多个可能匹配位置，已保留歧义：事件文本 %r（%d ms–%d ms）"
                % (ev.text, ev.start_ms, ev.end_ms)
            )

    if any(i["status"] == "suspected" for i in issues):
        status = "suspected"
    elif issues:
        status = "inconclusive"
    else:
        status = "no_issue_observed"
    return issues, warnings, status
