import json
import os
import shutil
import subprocess

from PIL import Image, ImageDraw, ImageFont

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ASSETS = os.path.join(ROOT, "tests", "assets")
FRAMES = os.path.join(ASSETS, "_frames")

FONT_CANDIDATES = [
    r"C:\Windows\Fonts\msyh.ttc",
    r"C:\Windows\Fonts\simhei.ttf",
    "/System/Library/Fonts/PingFang.ttc",
    "/usr/share/fonts/truetype/wqy/wqy-microhei.ttc",
]


def font(size):
    for p in FONT_CANDIDATES:
        try:
            return ImageFont.truetype(p, size)
        except OSError:
            continue
    raise RuntimeError("未找到可用中文字体，无法生成受控样本")


class Item:
    def __init__(self, text, kind, size, y_top, cx=None, x0=None, align="center", color=None, parts=1, dup=False):
        self.text = text
        self.kind = kind
        self.size = size
        self.y_top = y_top
        self.cx = cx
        self.x0 = x0
        self.align = align
        self.color = color or {"dynamic": (255, 255, 255), "fixed": (255, 206, 84), "bg": (120, 128, 140)}[kind]
        self.parts = parts
        self.dup = dup


def segments_for(item, draw):
    f = font(item.size)
    if item.parts > 1:
        n = item.parts
        chunk = max(1, (len(item.text) + n - 1) // n)
        chunks = [item.text[i:i + chunk] for i in range(0, len(item.text), chunk)]
    else:
        chunks = [item.text]
    gap = int(item.size * 0.18)
    widths = []
    for c in chunks:
        bb = draw.textbbox((0, 0), c, font=f)
        widths.append(bb[2] - bb[0])
    total = sum(widths) + gap * (len(chunks) - 1)
    if item.align == "right" and item.cx is not None:
        x = item.cx - total
    elif item.cx is not None:
        x = item.cx - total / 2.0
    else:
        x = item.x0
    out = []
    for c, w in zip(chunks, widths):
        bb = draw.textbbox((x, item.y_top), c, font=f)
        out.append((c, (bb[0], bb[1], bb[2], bb[3])))
        x = bb[2] + gap
    return out


def encode(out_path, fps, rotate=False, vfr_times=None):
    if vfr_times is None:
        cmd = ["ffmpeg", "-y", "-hide_banner", "-loglevel", "error",
               "-framerate", str(fps), "-i", os.path.join(FRAMES, "f_%05d.png"),
               "-c:v", "libx264", "-pix_fmt", "yuv420p", "-movflags", "+faststart"]
        if rotate:
            tmp = out_path + ".raw.mp4"
            cmd.append(tmp)
            subprocess.run(cmd, check=True, capture_output=True)
            subprocess.run(["ffmpeg", "-y", "-hide_banner", "-loglevel", "error",
                            "-display_rotation", "90", "-i", tmp, "-c", "copy", out_path],
                           check=True, capture_output=True)
            os.remove(tmp)
            return
        cmd.append(out_path)
    else:
        lines = ["ffconcat version 1.0"]
        for i, t in enumerate(vfr_times):
            dur = (vfr_times[i + 1] - t) if i + 1 < len(vfr_times) else 0.5
            lines.append("file 'f_%05d.png'" % i)
            lines.append("duration %.3f" % dur)
        lines.append("file 'f_%05d.png'" % (len(vfr_times) - 1))
        lst = os.path.join(FRAMES, "list.txt")
        with open(lst, "w", encoding="utf-8") as fh:
            fh.write("\n".join(lines))
        cmd = ["ffmpeg", "-y", "-hide_banner", "-loglevel", "error",
               "-f", "concat", "-safe", "0", "-i", lst,
               "-fps_mode", "vfr", "-c:v", "libx264", "-pix_fmt", "yuv420p", out_path]
    subprocess.run(cmd, check=True, capture_output=True)


def write_case(case_id, video_name, script_text, scripted, dyn_roi, fixed, base_fps=2.0,
               cloud_extra=None, write_scripted=True):
    os.makedirs(ASSETS, exist_ok=True)
    script_path = os.path.join(ASSETS, "%s_script.txt" % case_id)
    with open(script_path, "w", encoding="utf-8") as f:
        f.write(script_text)
    if write_scripted:
        scripted_path = os.path.join(ASSETS, "%s_scripted_ocr.json" % case_id)
        with open(scripted_path, "w", encoding="utf-8") as f:
            json.dump(scripted, f, ensure_ascii=False)
    else:
        scripted_path = cloud_extra.get("scripted_path")
    video_path = os.path.join(ASSETS, video_name)
    fx_block = {"present": fixed is not None,
                "roi": fixed,
                "exclude_from_dynamic_line_count": True,
                "exclude_from_script_alignment": True}
    cloud = {
        "ocr_enabled": True, "provider": "scripted", "scripted_path": scripted_path,
        "upload_confirmed": True, "max_calls_per_job": 5000, "max_cost_per_job": 50.0,
        "cost_per_call": 0.0, "timeout_ms": 20000, "max_retries": 2,
    }
    cloud.update(cloud_extra or {})
    cfg = {
        "schema_version": "lean-1.0",
        "video_path": video_path,
        "script_path": script_path,
        "capture": {"region_box": [0, 0.5, 1, 1]},
        "dynamic_subtitles": {"max_lines": 1, "roi": dyn_roi},
        "fixed_notice": fx_block,
        "text_normalization": {"ignore_whitespace": False, "ignore_punctuation": False},
        "sampling": {"base_fps": base_fps},
        "geometry": {"duplicate_box_tolerance": 0.85, "same_line_tolerance": 0.5},
        "event_grouping": {"text_similarity_threshold": 0.75, "max_gap_ms": 1200},
        "cloud": cloud,
    }
    cfg_path = os.path.join(ASSETS, "%s.config.json" % case_id)
    with open(cfg_path, "w", encoding="utf-8") as f:
        json.dump(cfg, f, ensure_ascii=False, indent=2)
    return cfg_path


def render_case(case_id, size, duration_s, cues, base_fps=2.0, enc_fps=24, rotate=False, vfr_times=None):
    W, H = size
    shutil.rmtree(FRAMES, ignore_errors=True)
    os.makedirs(FRAMES, exist_ok=True)

    if vfr_times is not None:
        times = vfr_times
    else:
        times = [i / enc_fps for i in range(int(duration_s * enc_fps))]

    for cue in cues:
        for item in cue["items"]:
            if item.cx is None and item.x0 is None:
                item.cx = W / 2.0

    for i, t in enumerate(times):
        img = Image.new("RGB", (W, H), (26, 28, 34))
        draw = ImageDraw.Draw(img)
        for cue in cues:
            if cue["start_s"] <= t < cue["end_s"]:
                for item in cue["items"]:
                    for seg_text, bb in segments_for(item, draw):
                        draw.text((bb[0], item.y_top), seg_text, font=font(item.size),
                                  fill=item.color, stroke_width=2, stroke_fill=(0, 0, 0))
        out = img
        if rotate:
            out = img.transpose(Image.Transpose.ROTATE_270)
        out.save(os.path.join(FRAMES, "f_%05d.png" % i))

    video_name = "%s.mp4" % case_id
    out_path = os.path.join(ASSETS, video_name)
    encode(out_path, enc_fps, rotate=rotate, vfr_times=vfr_times)

    scripted = {}
    step = 1000.0 / base_fps
    probe = ImageDraw.Draw(Image.new("RGB", (W, H)))
    count = int(duration_s * base_fps) + 1
    for k in range(count):
        t_ms = int(k * step)
        if t_ms >= duration_s * 1000 - 1:
            continue
        t = t_ms / 1000.0
        words = []
        for cue in cues:
            if cue["start_s"] <= t < cue["end_s"]:
                for item in cue["items"]:
                    for seg_text, bb in segments_for(item, probe):
                        crop_bb = [bb[0], bb[1] - H / 2.0, bb[2], bb[3] - H / 2.0]
                        words.append({"text": seg_text, "bbox": crop_bb})
                        if item.dup:
                            words.append({"text": seg_text, "bbox": [crop_bb[0] + 1.5, crop_bb[1] + 1.5,
                                                                     crop_bb[2] + 1.5, crop_bb[3] + 1.5]})
        scripted[t_ms] = words
    return out_path, scripted


def dyn_item(text, size, y_top, cx=None, **kw):
    return Item(text, "dynamic", size, y_top, cx=cx, **kw)


def fixed_pair(s):
    return [
        Item("点击关注", "fixed", int(20 * s), 0.885 * 960 * s, cx=0.94 * 540 * s, align="right"),
        Item("每天更新", "fixed", int(20 * s), 0.925 * 960 * s, cx=0.94 * 540 * s, align="right"),
    ]


def build_all():
    DYN_ROI = [0.06, 0.72, 0.94, 0.86]
    FIX_ROI = [0.55, 0.87, 0.98, 0.99]
    W, H = 540, 960
    Y1 = 0.755 * H
    YA, YB = 0.72 * H, 0.78 * H
    Y3A, Y3B, Y3C = 0.72 * H, 0.765 * H, 0.81 * H

    def make(case_id, size, duration, cues, script, dyn_roi=DYN_ROI, fixed=None, **kw):
        video, scripted = render_case(case_id, size, duration, cues, **kw)
        write_case(case_id, os.path.basename(video), script, scripted, dyn_roi, fixed,
                   base_fps=kw.get("base_fps", 2.0))
        print("built", case_id)

    make("L01", (W, H), 8, [
        {"start_s": 0, "end_s": 3.25, "items": [dyn_item("今天天气真好", 34, Y1)]},
        {"start_s": 3.25, "end_s": 7.75, "items": [dyn_item("适合出门散步", 34, Y1)]},
    ], "今天天气真好\n适合出门散步\n")

    make("L02", (W, H), 10.5, [
        {"start_s": 0, "end_s": 3.25, "items": [dyn_item("你好", 34, Y1)]},
        {"start_s": 3.25, "end_s": 5.75, "items": [
            dyn_item("第一句台词", 34, YA), dyn_item("第二句台词", 34, YB)]},
        {"start_s": 5.75, "end_s": 10.25, "items": [
            dyn_item("一", 30, Y3A), dyn_item("二", 30, Y3B), dyn_item("三", 30, Y3C)]},
    ], "你好\n第一句台词第二句台词\n一二三\n")

    make("L03", (W, H), 8, [
        {"start_s": 0, "end_s": 3.8, "items": [dyn_item("正常的一行台词", 34, Y1)]},
        {"start_s": 4.0, "end_s": 4.3, "items": [
            dyn_item("短暂双行上方", 34, YA), dyn_item("短暂双行下方", 34, YB)]},
        {"start_s": 4.6, "end_s": 7.8, "items": [dyn_item("之后又恢复单行", 34, Y1)]},
    ], "正常的一行台词\n短暂双行上方短暂双行下方\n之后又恢复单行\n")

    make("L04", (W, H), 8.5, [
        {"start_s": 0, "end_s": 4.0, "items": [
            dyn_item("今天天气真好适合出门", 34, Y1, parts=3, dup=True)]},
        {"start_s": 4.0, "end_s": 8.25, "items": [dyn_item("明天大概会下雨", 34, Y1)]},
    ], "今天天气真好适合出门\n明天大概会下雨\n")

    make("L05a", (W, H), 7, [
        {"start_s": 0, "end_s": 7, "items": fixed_pair(1.0)},
        {"start_s": 0, "end_s": 3.25, "items": [dyn_item("动态单行内容", 34, Y1)]},
        {"start_s": 3.25, "end_s": 6.75, "items": [dyn_item("第二句动态内容", 34, Y1)]},
    ], "动态单行内容\n第二句动态内容\n", fixed=FIX_ROI)

    make("L05b", (W, H), 6, [
        {"start_s": 0, "end_s": 6, "items": fixed_pair(1.0)},
    ], "全片只有固定提示没有动态台词\n", fixed=FIX_ROI)

    make("L05c", (W, H), 7, [
        {"start_s": 0, "end_s": 7, "items": fixed_pair(1.0) + [
            dyn_item("上方那行动态", 34, YA), dyn_item("下方这行动态", 34, YB)]},
    ], "上方那行动态下方这行动态\n", fixed=FIX_ROI)

    make("L06", (W, H), 7, [
        {"start_s": 0, "end_s": 7, "items": fixed_pair(1.0)},
        {"start_s": 0, "end_s": 3.25, "items": [
            Item("这句动态很长并伸入固定区", "dynamic", 30, 0.84 * H, cx=0.5 * W)]},
        {"start_s": 3.25, "end_s": 6.75, "items": [
            Item("背景水印", "bg", 26, 0.60 * H, cx=0.5 * W),
            dyn_item("正常短句", 34, Y1)]},
    ], "这句动态很长并伸入固定区\n正常短句\n", fixed=FIX_ROI)

    make("L07", (W, H), 16, [
        {"start_s": 0, "end_s": 3, "items": [dyn_item("我们今天去公园散步", 34, Y1)]},
        {"start_s": 3, "end_s": 6.5, "items": [dyn_item("然后吃饭看电影多了一杯", 34, Y1)]},
        {"start_s": 6.5, "end_s": 9, "items": [dyn_item("最后回家休息", 34, Y1)]},
        {"start_s": 9, "end_s": 10.5, "items": [dyn_item("再见", 34, Y1)]},
        {"start_s": 10.5, "end_s": 12.5, "items": [dyn_item("晚上早点睡记得关灯", 34, Y1)]},
        {"start_s": 12.5, "end_s": 15.75, "items": [dyn_item("明天见老阎友聊聊天喝喝茶", 34, Y1)]},
    ], "我们今天一起去公园散步\n然后吃饭看电影\n最后回家休息再见\n晚上早点睡\n记得关灯\n明天见老朋友聊聊天喝喝茶\n")

    long_a = "这是第一段比较长的台词内容专门用来验证顺序变化检测逻辑的字数超过了四十字符所以会被判定为大块差异"
    long_b = "这是第二段同样很长的台词内容顺序被故意调整了先出现用来验证不会输出连锁的逐字假差异结果"
    make("L08", (W, H), 21, [
        {"start_s": 0, "end_s": 2, "items": [dyn_item("你好呀", 34, Y1)]},
        {"start_s": 2.5, "end_s": 4.5, "items": [dyn_item("开始了吗", 34, Y1)]},
        {"start_s": 5, "end_s": 7, "items": [dyn_item("你好呀", 34, Y1)]},
        {"start_s": 7.5, "end_s": 8.2, "items": [dyn_item("我", 34, Y1)]},
        {"start_s": 8.5, "end_s": 9.2, "items": [dyn_item("我在", 34, Y1)]},
        {"start_s": 9.5, "end_s": 10.2, "items": [dyn_item("我在等", 34, Y1)]},
        {"start_s": 11.5, "end_s": 13.5, "items": [dyn_item("后说那个先", 34, Y1)]},
        {"start_s": 14, "end_s": 14.7, "items": [dyn_item("先说这个后", 34, Y1)]},
        {"start_s": 15.5, "end_s": 17.5, "items": [dyn_item(long_b, 26, Y1)]},
        {"start_s": 17.5, "end_s": 19.75, "items": [dyn_item(long_a, 26, Y1)]},
    ], "你好呀\n开始了吗\n你好呀\n我在等\n先说这个后说那个\n这段没有出现在字幕里\n后说那个先\n%s\n%s\n" % (long_a, long_b))

    make("L10a", (1080, 1920), 6, [
        {"start_s": 0, "end_s": 3.5, "items": [dyn_item("高分辨率测试台词", 68, 0.755 * 1920)]},
        {"start_s": 3.5, "end_s": 5.75, "items": [
            dyn_item("已知双行上", 68, 0.72 * 1920), dyn_item("已知双行下", 68, 0.78 * 1920)]},
    ], "高分辨率测试台词\n已知双行上已知双行下\n")

    make("L10b", (720, 1280), 6, [
        {"start_s": 0, "end_s": 3.5, "items": [dyn_item("小分辨率测试台词", 45, 0.755 * 1280)]},
        {"start_s": 3.5, "end_s": 5.75, "items": [
            dyn_item("已知双行上", 45, 0.72 * 1280), dyn_item("已知双行下", 45, 0.78 * 1280)]},
    ], "小分辨率测试台词\n已知双行上已知双行下\n")

    make("L10c", (W, H), 6, [
        {"start_s": 0, "end_s": 3.5, "items": [dyn_item("旋转视频测试台词", 34, Y1)]},
        {"start_s": 3.5, "end_s": 5.75, "items": [
            dyn_item("已知双行上", 34, YA), dyn_item("已知双行下", 34, YB)]},
    ], "旋转视频测试台词\n已知双行上已知双行下\n", rotate=True)

    make("L10d", (W, H), 6, [
        {"start_s": 0, "end_s": 3.5, "items": [dyn_item("可变帧率测试台词", 34, Y1)]},
        {"start_s": 3.5, "end_s": 5.75, "items": [
            dyn_item("已知双行上", 34, YA), dyn_item("已知双行下", 34, YB)]},
    ], "可变帧率测试台词\n已知双行上已知双行下\n",
        vfr_times=[0, 0.55, 1.1, 1.75, 2.3, 2.95, 3.5, 3.95, 4.05, 4.25, 4.6, 5.2, 5.75])

    with open(os.path.join(ASSETS, "L01_scripted_ocr.json"), "r", encoding="utf-8") as f:
        base = json.load(f)
    err_a = {}
    for k, v in base.items():
        err_a[k] = {"__error__": "timeout: 模拟请求超时"} if int(k) < 4000 else v
    with open(os.path.join(ASSETS, "L09a_scripted_ocr.json"), "w", encoding="utf-8") as f:
        json.dump(err_a, f, ensure_ascii=False)
    err_b = {k: {"__error__": "server: 模拟服务端错误"} for k in base}
    with open(os.path.join(ASSETS, "L09b_scripted_ocr.json"), "w", encoding="utf-8") as f:
        json.dump(err_b, f, ensure_ascii=False)
    empty = {k: [] for k in base}
    with open(os.path.join(ASSETS, "L09c_scripted_ocr.json"), "w", encoding="utf-8") as f:
        json.dump(empty, f, ensure_ascii=False)

    for variant in ("L09a", "L09b", "L09c"):
        write_case(variant, "L01.mp4", "今天天气真好\n适合出门散步\n", None, DYN_ROI, None,
                   cloud_extra={"scripted_path": os.path.join(ASSETS, "%s_scripted_ocr.json" % variant)},
                   write_scripted=False)
        print("built", variant)
    write_case("L09d", "L01.mp4", "今天天气真好\n适合出门散步\n", base, DYN_ROI, None,
               cloud_extra={"max_calls_per_job": 3})
    print("built L09d")

    with open(os.path.join(ASSETS, "L01.config.json"), encoding="utf-8") as f:
        l11 = json.load(f)
    l11["dynamic_subtitles"]["roi"] = None
    with open(os.path.join(ASSETS, "L11a.config.json"), "w", encoding="utf-8") as f:
        json.dump(l11, f, ensure_ascii=False, indent=2)
    with open(os.path.join(ASSETS, "L01.config.json"), encoding="utf-8") as f:
        l11b = json.load(f)
    l11b["script_path"] = os.path.join(ASSETS, "empty_script.txt")
    with open(os.path.join(ASSETS, "L11c.config.json"), "w", encoding="utf-8") as f:
        json.dump(l11b, f, ensure_ascii=False, indent=2)
    with open(os.path.join(ASSETS, "empty_script.txt"), "w", encoding="utf-8") as f:
        f.write("   \n  \n")


if __name__ == "__main__":
    build_all()
    print("all samples built at", ASSETS)
