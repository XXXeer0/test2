import argparse
import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from videoqc import config as cfg_mod
from videoqc.pipeline import load_script, run_pipeline


def main():
    ap = argparse.ArgumentParser(description="Video QC V1（精简版）单视频检查")
    ap.add_argument("config", help="lean-1.0 配置文件路径")
    ap.add_argument("--out", default="output", help="输出根目录")
    ap.add_argument("--ffmpeg", default="ffmpeg")
    args = ap.parse_args()

    cfg = cfg_mod.load_config(args.config)
    script_text = cfg.get("script_text")
    if script_text is None:
        sp = cfg.get("script_path")
        if not sp or not os.path.isfile(sp):
            print("错误：原稿文件不存在（script_path）", file=sys.stderr)
            sys.exit(2)
        try:
            script_text = load_script(sp)
        except cfg_mod.ConfigError as e:
            print("错误：%s" % e, file=sys.stderr)
            sys.exit(2)

    def progress(stage, detail, pct):
        print("[%3d%%] %-10s %s" % (pct, stage, detail), flush=True)

    result = run_pipeline(cfg, script_text, out_root=args.out, progress=progress, ffmpeg=args.ffmpeg)

    print()
    if result["run_status"] == "needs_input":
        print("状态：待补输入（未开始检测）")
        for e in result["errors"]:
            print("  - %s" % e)
        sys.exit(2)
    print("运行：%s" % result["run_id"])
    print("状态：%s" % result["run_status"])
    print("检查一 原稿↔动态字幕核对：%s" % result["checks"]["script_alignment"])
    print("检查二 动态字幕严格单行：%s" % result["checks"]["dynamic_single_line"])
    print("问题数：%d（疑似 %d，不确定 %d）" % (
        len(result["issues"]),
        sum(1 for i in result["issues"] if i["status"] == "suspected"),
        sum(1 for i in result["issues"] if i["status"] == "inconclusive"),
    ))
    print("报告：%s" % os.path.join(args.out, result["run_id"], "report.html"))
    for w in result["warnings"][:10]:
        print("警告：%s" % w)


if __name__ == "__main__":
    main()
