# Video QC V1 精简版（Lean 1.0）

按《Video QC V1 智谱精简开发任务书》实现的第一次可运行交付。

**两条核心工作流 + 位置检测（迭代四新增）：**

1. 检查一：原稿台词 ↔ 成片动态对白字幕 OCR 文本核对（漏字 / 多字 / 替换 / 无法对齐，含原稿定位、时间与截图证据）
2. 检查二：动态对白字幕严格单行审查（`max_lines = 1`，同一采样时刻两行及以上即疑似违规，不设持续时长门槛）
3. 检查三（可选，默认开启于界面）：字幕位置合规——动态字幕须落在标准字幕带内（默认带由剪映 9:16 同源字幕位 x:0, y:-478 换算为 [0.02, 0.68, 0.98, 0.85]），超带写入报告（疑似项，附截图）；配置文件中 `expected_band` 为 null 时关闭（受控回归样本默认不受影响）

必要支撑：固定提示（合法两行）独立隔离、云端 OCR 仅上传下半区裁剪图、几何归行与坐标回映射、PTS 毫秒时间基准、静态 HTML 问题清单 + JSON + 证据截图、失败与覆盖缺口如实可见（partial / failed / unavailable，不输出"通过"承诺）。

## 环境要求

- Windows 10/11，Python 3.10+
- ffmpeg / ffprobe 已安装并加入 PATH（本项目在 ffmpeg 9.0 下开发验证）
- 安装依赖：

```bash
pip install -r requirements.txt
```

**默认 OCR 后端为本地推理（rapidocr，PP-OCRv4 ONNX 检测+识别）**：无需密钥、不上传任何数据、零云端费用，返回四点几何框。CPU 即可运行（约 0.7–1.2 秒/帧）；RTX 4060 8GB 可通过 `pip install onnxruntime-gpu` 启用 GPU 提速（无需改代码）。

## 快速开始

### 桌面界面（推荐）

```bash
python main.py
```

界面操作流程（三步引导式，普通用户无需理解参数）：

1. ① 选择成片：选 MP4（自动读取显示尺寸、旋转、时长）；
2. ② 上传 / 粘贴剧本原稿：可直接粘贴完整剧本（支持「角色名：台词」「角色名（动作）：台词」「角色名 os/旁白：台词」格式），点「解析剧本（自动提取台词）」自动剔除集数/场次头（第X集、"35-1 日 内 …"）、人物表行、▲/△ 舞台指示、整行括注与空行，提取纯台词（认不出的行默认保留，由人工检查）；也可粘贴已清理好的纯台词；
3. ③ 圈出字幕区域：点「圈出字幕出现的区域」在预览下半区拖拽矩形，或直接点「使用标准字幕位置」一键应用标准带；
4. 识别方式默认「本机识别」（不上传、免费、免配置）；需要云端/演示数据时切换下拉，对应字段才会出现；固定提示、位置检测开关与标准带范围、忽略标点差异（默认勾选：成片字幕一般不带标点）、抽样密度、超时重试、费用上限在「更多设置」（默认折叠，默认值已调好）；
5. 点击「开始检测」，查看人话进度（读取视频信息 → 抽取画面帧 → 识别字幕 → 比对原稿 → 生成报告）；完成后点击「打开问题报告」（含检查三：字幕位置状态；使用剧本解析时，问题定位显示「台词序号 + 角色」）。

### 命令行（同一条管道）

```bash
python run_cli.py config.example.local.json
```

示例配置说明：

- `config.example.local.json`：本地 OCR（provider=rapidocr，绑定受控小样 L01，可一键运行验证本地链路，OCR 为真实推理）
- `config.example.json`：受控小样（provider=scripted，本地预制 OCR 结果，用于规则回归验证，不联网）
- `config.example.aliyun.json`：云端模板（video/script/ROI 待填，密钥不写入文件）

阿里云密钥读取顺序：界面输入（保存于 `%USERPROFILE%\.videoqc\credentials.json`）→ 环境变量 `ALIBABA_CLOUD_ACCESS_KEY_ID` / `ALIBABA_CLOUD_ACCESS_KEY_SECRET` → 本地凭据文件。密钥不进入配置快照、报告与日志。

## 输出结构

每次运行生成独立目录（互不影响，重复运行生成新目录）：

```text
output/<run_id>/
  report.html           静态问题清单（与 result.json 同源生成）
  result.json           结构化结果
  config.snapshot.json  配置快照（已去除密钥）
  evidence/             证据截图（完整画面叠框 + 局部放大）
  raw/ocr.jsonl         每次采样的原始 OCR 返回
  run.log               运行日志
```

## 结果语义（重要）

- `run_status`：`needs_input`（开始前缺输入）/ `completed`（执行正常结束，**不代表视频合格**）/ `partial`（存在失败或覆盖缺口，保留已有结果）/ `failed`（无法产生可用核心结果）
- 两项检查各自报告 `suspected`（存在可信疑似候选）/ `inconclusive`（无法可靠判断）/ `no_issue_observed`（**有效采样范围内**未发现候选）/ `unavailable`（未执行或无可用数据）
- 采样间隔内可能存在未采到的短暂事件（报告标注定位误差）；OCR 空返回按保守口径记为覆盖缺口，不当作"无字幕"或全片漏字；原稿与字幕的缺口标注"OCR 未识别也可能"，不判定原片漏字幕
- 报告无"全片合格"按钮或总分

## 配置参数说明

`config.example.aliyun.json` 中已填数值均为**开发者建议值**（经受控小样验证），不代表用户已确认的验收标准：

| 参数 | 建议值 | 说明 |
|---|---|---|
| sampling.base_fps | 2.0 | 每秒采样帧数；时间定位误差约等于采样间隔 |
| geometry.duplicate_box_tolerance | 0.85 | 重复框/描边去重 IoU 阈值 |
| geometry.same_line_tolerance | 0.5 | 垂直重叠率归行阈值（同视觉行判定） |
| event_grouping.text_similarity_threshold | 0.75 | 相邻采样文本相似度（事件延续/分割） |
| event_grouping.max_gap_ms | 1200 | 事件间最大允许空隙（毫秒） |
| cloud.cost_per_call | 0.01 元 | 单次调用费用估算（按实际账单修正） |

## 受控样本与验收

```bash
python tools\make_samples.py        # 重新生成 L01–L12 受控合成样本（真实 MP4 + 预制 OCR 框）
python tests\run_acceptance.py      # 规则验收（L01–L12，输出 tests/acceptance.md）
python tests\test_local_smoke.py    # 本地 OCR 端到端冒烟（真实推理，输出 tests/acceptance_local.md）
python tests\test_ui_offscreen.py   # 界面冒烟（选视频→设ROI→开始→报告，输出 tests/acceptance_ui.md）
```

受控样本结论与真实成片效果说明：受控合成样本验证规则逻辑；本地 OCR 后端已通过真实推理冒烟（L01 合成视频识别正确、双检查 no_issue_observed）；**真实成片上的识别效果仍待真实样本到位后记录**（阈值调优同上）。

## 已知限制与暂缓项

- 暂缓（任务书第 3 节）：ASR 与声画同步、安全区/字体/字号/颜色/停留时长检查、固定提示内容核验（仅隔离）、批量处理与断点续跑、人工确认/驳回状态管理、复杂缓存与智能区域发现、DOCX 直接解析（Word 请先导出 UTF-8 纯文本）
- 真实窗口模式下 ROI 拖拽交互与后台线程进度需人工运行 `python main.py` 复核（offscreen 冒烟已验证同一配置与同一管道函数）
- 本地 OCR（rapidocr）默认 CPU 推理（约 1.2s/帧含抽帧）；GPU 提速（onnxruntime-gpu）未在本环境验证
- 阿里云读光适配层保留可选（`prism_wordsInfo` 四点坐标解析已实现），真实调用与费用以实测为准；云端空返回沿用保守口径（本地后端同样沿用，后续可按任务书 5.2 用样本验证后放开"确无文字"语义）
