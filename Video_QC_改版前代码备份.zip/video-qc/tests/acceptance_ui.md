# Video QC V1 界面冒烟测试记录（offscreen 自动化）

执行时间：2026-10-17 00:16:54

冒烟路径：选视频 → 设 ROI → 开始检测 → 生成报告。
说明：检测以界面组装的同一份配置同步执行（与点击开始按钮后 Worker 线程执行的 run_pipeline 为同一函数与同一配置来源）；
真实窗口模式下的 ROI 拖拽交互与后台线程异步进度展示，仍需人工运行 python main.py 复核。

| 断言 | 结果 | 说明 |
|---|---|---|
| S1 选视频（元数据读取） | 通过 | 显示 540×960（rotation 0.0°）· 时长 8.0s · 无音轨 |
| S2 设 ROI（动态+固定） | 通过 |  |
| S2b ROI 弹窗可构建（真实抽帧渲染，防回归 21:15 修复项） | 通过 |  |
| S3a 新界面默认本机识别且更多设置已折叠 | 通过 | rapidocr/False |
| S3b 位置检测默认开启且标准带合法（迭代四新增） | 通过 | [0.02, 0.68, 0.98, 0.85] |
| S3c 剧本解析提取台词与剔除（迭代四新增） | 通过 | 今天天气真好 适合出门散步 好 |
| S3d 对解析结果重复点击解析被拦截且元数据保留（界面修复新增） | 通过 | ['已经是解析结果'] |
| S4a 空原稿开始前拦截（未启动检测） | 通过 | ['当前文本就是上次解析出的纯台词，无需重复解析（重复解析不会有效果）。\n如需重新解析原始剧本，请先粘贴或载入剧本原文再点「解析剧本」。', '原稿为空，请补齐台词内容'] |
| S4b 缺动态 ROI 开始前拦截 | 通过 | ['动态字幕 ROI 必填，格式 [x0,y0,x1,y1]，归一化坐标且有正面积'] |
| S5 检测流程执行完毕（1.2s） | 通过 | completed |
| S6a 报告文件生成 | 通过 | C:\Users\ASUS\Desktop\视频项目demo\tests\acceptance_out\UI_SMOKE\20261017-001652-fe59a9\report.html |
| S6b 界面状态栏呈现两项检查结果 | 通过 | 运行 completed ｜ 检查一（原稿核对）：no_issue_observed ｜ 检查二（严格单行）：no_issue_observed ｜ 检查三（字幕位置）：disabled ｜ 问题 0 项（疑似 0 / 不确定 0） |
| S6c 检查一 no_issue_observed | 通过 | {'script_alignment': 'no_issue_observed', 'dynamic_single_line': 'no_issue_observed', 'subtitle_position': 'disabled'} |
| S6d 检查二 no_issue_observed | 通过 | {'script_alignment': 'no_issue_observed', 'dynamic_single_line': 'no_issue_observed', 'subtitle_position': 'disabled'} |
| S6e 输出目录结构完整 | 通过 | C:\Users\ASUS\Desktop\视频项目demo\tests\acceptance_out\UI_SMOKE\20261017-001652-fe59a9 |
| S6f 快照不含密钥 | 通过 |  |
| S7 重跑生成独立目录 | 通过 | 20261017-001653-7c96b2 |

通过 17 / 17