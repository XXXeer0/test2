import json
import os
import shutil
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

from videoqc import config as cfg_mod
from videoqc.pipeline import load_script, run_pipeline

ASSETS = os.path.join(ROOT, "tests", "assets")
OUT_ROOT = os.path.join(ROOT, "tests", "acceptance_out")
RESULTS = []


def run_case(name, cfg, script_text=None):
    out = os.path.join(OUT_ROOT, name)
    if script_text is None:
        script_text = load_script(cfg["script_path"])
    return run_pipeline(cfg, script_text, out_root=out)


def load_cfg(path):
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def check(case, name, cond, detail=""):
    RESULTS.append((case, name, bool(cond), str(detail)[:200]))
    return bool(cond)


def kinds(result, kind):
    return [i for i in result.get("issues", []) if i.get("kind") == kind]


def main():
    shutil.rmtree(OUT_ROOT, ignore_errors=True)
    os.makedirs(OUT_ROOT, exist_ok=True)

    r = run_case("L01", load_cfg(os.path.join(ASSETS, "L01.config.json")))
    check("L01", "run_status=completed", r["run_status"] == "completed", r["run_status"])
    check("L01", "检查二 no_issue_observed", r["checks"]["dynamic_single_line"] == "no_issue_observed",
          r["checks"]["dynamic_single_line"])
    check("L01", "检查一 no_issue_observed", r["checks"]["script_alignment"] == "no_issue_observed",
          r["checks"]["script_alignment"])
    check("L01", "无问题项", not r["issues"], len(r["issues"]))

    r = run_case("L02", load_cfg(os.path.join(ASSETS, "L02.config.json")))
    exc = kinds(r, "dynamic_line_count_exceeded")
    obs_set = set(f["dynamic_count"] for i in exc for f in i["frames"])
    check("L02", "双行与三行均产生疑似（可合并显示）", len(exc) >= 1, len(exc))
    check("L02", "原始单帧候选保留观察行数 {2,3}（不只检测三行）",
          obs_set == {2, 3}, sorted(obs_set))
    check("L02", "检查一可对齐（多行帧文本仍参与）", r["checks"]["script_alignment"] in ("no_issue_observed", "suspected"),
          r["checks"]["script_alignment"])

    r = run_case("L03", load_cfg(os.path.join(ASSETS, "L03.config.json")))
    exc = kinds(r, "dynamic_line_count_exceeded")
    check("L03", "短暂双行未被时长门槛抹掉", len(exc) == 1, len(exc))
    if exc:
        check("L03", "疑似项时间接近 4000ms", abs(exc[0]["start_ms"] - 4000) <= 700, exc[0]["start_ms"])
        check("L03", "原始单帧候选保留（frames）", len(exc[0]["frames"]) >= 1, len(exc[0]["frames"]))

    r = run_case("L04", load_cfg(os.path.join(ASSETS, "L04.config.json")))
    check("L04", "多框+描边归并后仍为单行（无误报）", not kinds(r, "dynamic_line_count_exceeded"),
          len(kinds(r, "dynamic_line_count_exceeded")))
    check("L04", "先后不同单行成 2 个事件", len(r["events"]) == 2, len(r["events"]))
    check("L04", "检查一 no_issue", r["checks"]["script_alignment"] == "no_issue_observed",
          r["checks"]["script_alignment"])

    for case, expect_align, note in (("L05a", "no_issue_observed", "动态单行+固定两行"),
                                     ("L05b", "unavailable", "仅固定两行"),
                                     ("L05c", None, "双行动态+固定两行")):
        r = run_case(case, load_cfg(os.path.join(ASSETS, "%s.config.json" % case)))
        exc = kinds(r, "dynamic_line_count_exceeded")
        if case == "L05c":
            check("L05c", "仅动态双行触发疑似（固定两行不计入）",
                  len(exc) == 1 and exc[0]["observed_dynamic_lines"] == 2,
                  [(i["observed_dynamic_lines"]) for i in exc])
        else:
            check(case, "动态行数判断正确（%s）" % note,
                  r["checks"]["dynamic_single_line"] == "no_issue_observed",
                  r["checks"]["dynamic_single_line"])
        if expect_align:
            check(case, "检查一状态符合预期（%s）" % note, r["checks"]["script_alignment"] == expect_align,
                  r["checks"]["script_alignment"])
    r05b = run_case("L05b", load_cfg(os.path.join(ASSETS, "L05b.config.json")))
    check("L05b", "全片无动态字幕时给出警告而非全稿漏字",
          any("无可用动态字幕" in w for w in r05b["warnings"]), r05b["warnings"])

    r = run_case("L06", load_cfg(os.path.join(ASSETS, "L06.config.json")))
    check("L06", "重叠/跨界文字记 region_conflict（不遮盖）", len(kinds(r, "region_conflict")) >= 1,
          len(kinds(r, "region_conflict")))
    check("L06", "行数不确定可见", len(kinds(r, "line_count_uncertain")) >= 1,
          len(kinds(r, "line_count_uncertain")))
    check("L06", "背景字记为未归类警告", any("未能归类" in w for w in r["warnings"]), r["warnings"])

    r = run_case("L07", load_cfg(os.path.join(ASSETS, "L07.config.json")))
    mm = kinds(r, "text_mismatch")
    subs = set(i.get("sub") for i in r["issues"])
    check("L07", "漏字被检出（missing，不判定漏字幕）",
          any(i.get("sub") == "missing" and i["status"] == "inconclusive" for i in r["issues"]), subs)
    check("L07", "多字被检出（extra）", "extra" in subs, subs)
    check("L07", "文字替换被检出（replace）", "replace" in subs, subs)
    check("L07", "一句拆多条/多句合一条不产生连锁假差异",
          r["checks"]["script_alignment"] == "suspected" and len(mm) <= 5,
          (r["checks"]["script_alignment"], len(mm)))
    check("L07", "问题含原稿定位与差异位置",
          all(i.get("script_ref") or i.get("sub") == "extra" for i in mm), [i.get("script_ref") for i in mm])

    r = run_case("L08", load_cfg(os.path.join(ASSETS, "L08.config.json")))
    unc = kinds(r, "alignment_uncertain")
    check("L08", "大段顺序变化列为无法对齐候选", any(i.get("sub") in ("large_replace", "missing") for i in unc) or len(unc) >= 1,
          [(i.get("kind"), i.get("sub")) for i in unc])
    check("L08", "OCR 缺失不直接断言为原片漏字幕（均为 inconclusive）",
          all(i["status"] == "inconclusive" for i in r["issues"] if i.get("sub") == "missing"),
          [(i.get("kind"), i.get("sub"), i["status"]) for i in r["issues"]])
    check("L08", "重复台词保留歧义警告", any("重复" in w or "歧义" in w for w in r["warnings"]), r["warnings"])
    texts = [e["text"] for e in r["events"]]
    check("L08", "两次'你好呀'为两个独立事件", texts.count("你好呀") == 2, texts)
    check("L08", "逐字显现合并为一个事件（取稳定文本）", "我在等" in texts, texts)
    small_mm = [i for i in kinds(r, "text_mismatch") if i.get("sub") == "replace"]
    check("L08", "顺序异常未输出一长串逐字假差异", len(small_mm) <= 2, len(small_mm))

    r = run_case("L09a", load_cfg(os.path.join(ASSETS, "L09a.config.json")))
    check("L09a", "存在失败点时为 partial 而非 completed", r["run_status"] == "partial", r["run_status"])
    check("L09a", "覆盖缺口可见", len(r["coverage"]["gaps"]) >= 1, r["coverage"]["gaps"])
    check("L09a", "保留已有结果（非 failed）", r["run_status"] != "failed", r["run_status"])

    r = run_case("L09b", load_cfg(os.path.join(ASSETS, "L09b.config.json")))
    check("L09b", "全片调用失败为 failed", r["run_status"] == "failed", r["run_status"])
    check("L09b", "两项检查 unavailable", r["checks"]["script_alignment"] == "unavailable"
          and r["checks"]["dynamic_single_line"] == "unavailable", r["checks"])

    r = run_case("L09c", load_cfg(os.path.join(ASSETS, "L09c.config.json")))
    check("L09c", "全片空返回（保守口径）不输出通过", r["run_status"] in ("failed", "partial"), r["run_status"])
    check("L09c", "不当作无字幕/全部漏字", r["checks"]["script_alignment"] == "unavailable",
          r["checks"]["script_alignment"])

    r = run_case("L09d", load_cfg(os.path.join(ASSETS, "L09d.config.json")))
    check("L09d", "超限停止为 partial 且保留已有结果", r["run_status"] == "partial", r["run_status"])
    check("L09d", "实际处理数受上限约束", r["coverage"]["processed_samples"] == 3, r["coverage"]["processed_samples"])
    check("L09d", "未覆盖区间记为缺口", any("上限" in g.get("reason", "") for g in r["coverage"]["gaps"]),
          r["coverage"]["gaps"])

    for case in ("L10a", "L10b", "L10c", "L10d"):
        r = run_case(case, load_cfg(os.path.join(ASSETS, "%s.config.json" % case)))
        exc = kinds(r, "dynamic_line_count_exceeded")
        check(case, "已知双行时刻被检出", len(exc) == 1 and exc[0]["observed_dynamic_lines"] == 2,
              [(i["observed_dynamic_lines"]) for i in exc])
        if exc:
            check(case, "时间依据真实（≈4000ms）", abs(exc[0]["start_ms"] - 4000) <= 700, exc[0]["start_ms"])
            ev = exc[0].get("evidence") or []
            ok_png = [e for e in ev if e["path"].endswith(".png") and os.path.isfile(
                os.path.join(OUT_ROOT, case, r["run_id"], e["path"]))]
            check(case, "证据截图真实存在（框映射链路可用）", len(ok_png) >= 1, len(ok_png))

    r = run_case("L11a", load_cfg(os.path.join(ASSETS, "L11a.config.json")))
    check("L11a", "缺动态 ROI 时 needs_input 且未开始检测", r["run_status"] == "needs_input", r["run_status"])
    check("L11a", "明确提示补齐", any("ROI" in e for e in r["errors"]), r["errors"])

    r = run_case("L11c", load_cfg(os.path.join(ASSETS, "L11c.config.json")))
    check("L11c", "空原稿时 needs_input", r["run_status"] == "needs_input", r["run_status"])
    check("L11c", "明确提示原稿为空", any("原稿" in e for e in r["errors"]), r["errors"])

    cn_dir = os.path.join(ASSETS, "测试 目录")
    os.makedirs(cn_dir, exist_ok=True)
    cn_video = os.path.join(cn_dir, "样本 A.mp4")
    shutil.copy(os.path.join(ASSETS, "L01.mp4"), cn_video)
    cfg = load_cfg(os.path.join(ASSETS, "L01.config.json"))
    cfg["video_path"] = cn_video
    r = run_case("L12a", cfg)
    check("L12a", "中文与空格路径正常完成", r["run_status"] == "completed" and r["run_id"], r["run_status"])
    check("L12a", "检查结果不受路径影响", r["checks"]["dynamic_single_line"] == "no_issue_observed",
          r["checks"])

    cfg = load_cfg(os.path.join(ASSETS, "L01.config.json"))
    r = run_case("L12b", cfg, script_text="<script>alert(1)</script>今天天气真好\n适合出门散步\n")
    html_path = os.path.join(OUT_ROOT, "L12b", r["run_id"], "report.html")
    html = open(html_path, encoding="utf-8").read()
    check("L12b", "原稿含 HTML 标签时报告不执行脚本", "<script>alert" not in html, "found raw tag")
    check("L12b", "文本已转义呈现", "&lt;script&gt;" in html, "escaped tag missing")

    r1 = run_case("L12d", load_cfg(os.path.join(ASSETS, "L01.config.json")))
    r2 = run_case("L12d", load_cfg(os.path.join(ASSETS, "L01.config.json")))
    check("L12d", "重复运行生成独立目录（不依赖复核数据库）",
          r1["run_id"] != r2["run_id"]
          and os.path.isdir(os.path.join(OUT_ROOT, "L12d", r1["run_id"]))
          and os.path.isdir(os.path.join(OUT_ROOT, "L12d", r2["run_id"])),
          (r1["run_id"], r2["run_id"]))

    passed = sum(1 for x in RESULTS if x[2])
    lines = [
        "# Video QC V1 受控样本验收记录",
        "",
        "执行时间：%s ｜ 程序版本见 result.json ｜ 参数均为开发者建议值（待用户确认），不作为验收标准。"
        % __import__("time").strftime("%Y-%m-%d %H:%M:%S"),
        "",
        "受控合成样本仅验证规则逻辑；真实成片上的 OCR 效果尚未验证（真实样本待提供后另行记录）。",
        "",
        "| 用例 | 断言 | 结果 | 说明 |",
        "|---|---|---|---|",
    ]
    for case, name, ok, detail in RESULTS:
        lines.append("| %s | %s | %s | %s |" % (case, name, "通过" if ok else "未通过", detail.replace("|", "/").replace("\n", " ")))
    lines.append("")
    lines.append("通过 %d / %d" % (passed, len(RESULTS)))
    out_md = os.path.join(ROOT, "tests", "acceptance.md")
    with open(out_md, "w", encoding="utf-8") as f:
        f.write("\n".join(lines))
    print("\n".join(lines[-3:]))
    print("written:", out_md)
    if passed != len(RESULTS):
        sys.exit(1)


if __name__ == "__main__":
    main()
