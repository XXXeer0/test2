# Video QC V1 本地 OCR 后端（rapidocr）冒烟测试记录

执行时间：2026-10-16 23:38:56
后端：rapidocr（PP-OCRv4 ONNX 检测+识别，本地推理，CPU）
样本：受控合成 MP4（L01，真实视频帧真实 OCR 推理，非预制结果）
总耗时 18.6s ｜ 调用 16 次 ｜ 失败 0 次 ｜ 均耗 1.16s/帧

| 断言 | 结果 | 说明 |
|---|---|---|
| LS0 本地配置校验通过（无密钥、无上传确认要求） | 通过 | [] |
| LS1 运行结束且不失败（completed/partial） | 通过 | completed |
| LS2 本地 OCR 真实调用全部成功（无调用失败） | 通过 | 0 |
| LS3 检查二状态可用（识别到动态字幕） | 通过 | {'script_alignment': 'no_issue_observed', 'dynamic_single_line': 'no_issue_observed', 'subtitle_position': 'disabled'} |
| LS4 检查一状态可用（可对齐） | 通过 | {'script_alignment': 'no_issue_observed', 'dynamic_single_line': 'no_issue_observed', 'subtitle_position': 'disabled'} |
| LS5 真实识别出字幕事件（非预制结果） | 通过 | ['今天天气真好', '适合出门散步'] |
| LS6 报告与输出结构完整 | 通过 | C:\Users\ASUS\Desktop\视频项目demo\tests\acceptance_out\LOCAL_SMOKE\20261016-233837-2a353e |
| LS7 快照不含密钥且零费用 | 通过 | 0.0 |
| LS8 性能可接受（CPU 本地，均耗 < 3s/帧） | 通过 | 1.16s/帧 |

通过 9 / 9

说明：本次为本地后端冒烟；真实成片识别效果与阈值调优待真实样本到位后另行记录。