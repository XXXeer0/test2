# Video QC V1 受控样本验收记录

执行时间：2026-10-16 23:38:12 ｜ 程序版本见 result.json ｜ 参数均为开发者建议值（待用户确认），不作为验收标准。

受控合成样本仅验证规则逻辑；真实成片上的 OCR 效果尚未验证（真实样本待提供后另行记录）。

| 用例 | 断言 | 结果 | 说明 |
|---|---|---|---|
| L01 | run_status=completed | 通过 | completed |
| L01 | 检查二 no_issue_observed | 通过 | no_issue_observed |
| L01 | 检查一 no_issue_observed | 通过 | no_issue_observed |
| L01 | 无问题项 | 通过 | 0 |
| L02 | 双行与三行均产生疑似（可合并显示） | 通过 | 1 |
| L02 | 原始单帧候选保留观察行数 {2,3}（不只检测三行） | 通过 | [2, 3] |
| L02 | 检查一可对齐（多行帧文本仍参与） | 通过 | no_issue_observed |
| L03 | 短暂双行未被时长门槛抹掉 | 通过 | 1 |
| L03 | 疑似项时间接近 4000ms | 通过 | 4000 |
| L03 | 原始单帧候选保留（frames） | 通过 | 1 |
| L04 | 多框+描边归并后仍为单行（无误报） | 通过 | 0 |
| L04 | 先后不同单行成 2 个事件 | 通过 | 2 |
| L04 | 检查一 no_issue | 通过 | no_issue_observed |
| L05a | 动态行数判断正确（动态单行+固定两行） | 通过 | no_issue_observed |
| L05a | 检查一状态符合预期（动态单行+固定两行） | 通过 | no_issue_observed |
| L05b | 动态行数判断正确（仅固定两行） | 通过 | no_issue_observed |
| L05b | 检查一状态符合预期（仅固定两行） | 通过 | unavailable |
| L05c | 仅动态双行触发疑似（固定两行不计入） | 通过 | [2] |
| L05b | 全片无动态字幕时给出警告而非全稿漏字 | 通过 | ['全片无可用动态字幕，无法完成原稿核对；不输出原稿全部漏字'] |
| L06 | 重叠/跨界文字记 region_conflict（不遮盖） | 通过 | 1 |
| L06 | 行数不确定可见 | 通过 | 1 |
| L06 | 背景字记为未归类警告 | 通过 | ['存在 7 处未能归类的文字（背景字/角标/区域外），未参与两项检查，详见截图与 raw 数据', '问题 issue-003 缺少真实截图（抽帧或解码失败），未使用伪造图片代替证据'] |
| L07 | 漏字被检出（missing，不判定漏字幕） | 通过 | {'extra', 'replace', 'missing'} |
| L07 | 多字被检出（extra） | 通过 | {'extra', 'replace', 'missing'} |
| L07 | 文字替换被检出（replace） | 通过 | {'extra', 'replace', 'missing'} |
| L07 | 一句拆多条/多句合一条不产生连锁假差异 | 通过 | ('suspected', 3) |
| L07 | 问题含原稿定位与差异位置 | 通过 | [None, {'para_index': 5, 'para_char_start': 4, 'para_char_end': 5, 'cross_para': False, 'ambiguous': False}, {'para_index': 0, 'para_char_start': 4, 'para_char_end': 6, 'cross_para': False, 'ambiguous |
| L08 | 大段顺序变化列为无法对齐候选 | 通过 | [('alignment_uncertain', 'missing')] |
| L08 | OCR 缺失不直接断言为原片漏字幕（均为 inconclusive） | 通过 | [('text_mismatch', 'extra', 'suspected'), ('alignment_uncertain', 'missing', 'inconclusive'), ('line_count_uncertain', None, 'inconclusive'), ('region_conflict', None, 'inconclusive')] |
| L08 | 重复台词保留歧义警告 | 通过 | ["重复台词存在多个可能匹配位置，已保留歧义：事件文本 '你好呀'（0 ms–1500 ms）", "重复台词存在多个可能匹配位置，已保留歧义：事件文本 '你好呀'（5000 ms–6500 ms）"] |
| L08 | 两次'你好呀'为两个独立事件 | 通过 | ['你好呀', '开始了吗', '你好呀', '我在等', '后说那个先', '先说这个后'] |
| L08 | 逐字显现合并为一个事件（取稳定文本） | 通过 | ['你好呀', '开始了吗', '你好呀', '我在等', '后说那个先', '先说这个后'] |
| L08 | 顺序异常未输出一长串逐字假差异 | 通过 | 0 |
| L09a | 存在失败点时为 partial 而非 completed | 通过 | partial |
| L09a | 覆盖缺口可见 | 通过 | [{'start_ms': 0, 'end_ms': 3500, 'reason': 'OCR 调用失败（timeout: 模拟请求超时）'}] |
| L09a | 保留已有结果（非 failed） | 通过 | partial |
| L09b | 全片调用失败为 failed | 通过 | failed |
| L09b | 两项检查 unavailable | 通过 | {'script_alignment': 'unavailable', 'dynamic_single_line': 'unavailable', 'subtitle_position': 'disabled'} |
| L09c | 全片空返回（保守口径）不输出通过 | 通过 | failed |
| L09c | 不当作无字幕/全部漏字 | 通过 | unavailable |
| L09d | 超限停止为 partial 且保留已有结果 | 通过 | partial |
| L09d | 实际处理数受上限约束 | 通过 | 3 |
| L09d | 未覆盖区间记为缺口 | 通过 | [{'start_ms': 1500, 'end_ms': 7500, 'reason': '超出调用/费用上限，停止并保留已有结果'}] |
| L10a | 已知双行时刻被检出 | 通过 | [2] |
| L10a | 时间依据真实（≈4000ms） | 通过 | 3500 |
| L10a | 证据截图真实存在（框映射链路可用） | 通过 | 4 |
| L10b | 已知双行时刻被检出 | 通过 | [2] |
| L10b | 时间依据真实（≈4000ms） | 通过 | 3500 |
| L10b | 证据截图真实存在（框映射链路可用） | 通过 | 4 |
| L10c | 已知双行时刻被检出 | 通过 | [2] |
| L10c | 时间依据真实（≈4000ms） | 通过 | 3500 |
| L10c | 证据截图真实存在（框映射链路可用） | 通过 | 4 |
| L10d | 已知双行时刻被检出 | 通过 | [2] |
| L10d | 时间依据真实（≈4000ms） | 通过 | 3500 |
| L10d | 证据截图真实存在（框映射链路可用） | 通过 | 4 |
| L11a | 缺动态 ROI 时 needs_input 且未开始检测 | 通过 | needs_input |
| L11a | 明确提示补齐 | 通过 | ['动态字幕 ROI 必填，格式 [x0,y0,x1,y1]，归一化坐标且有正面积'] |
| L11c | 空原稿时 needs_input | 通过 | needs_input |
| L11c | 明确提示原稿为空 | 通过 | ['原稿为空，请补齐台词内容'] |
| L12a | 中文与空格路径正常完成 | 通过 | completed |
| L12a | 检查结果不受路径影响 | 通过 | {'script_alignment': 'no_issue_observed', 'dynamic_single_line': 'no_issue_observed', 'subtitle_position': 'disabled'} |
| L12b | 原稿含 HTML 标签时报告不执行脚本 | 通过 | found raw tag |
| L12b | 文本已转义呈现 | 通过 | escaped tag missing |
| L12d | 重复运行生成独立目录（不依赖复核数据库） | 通过 | ('20261016-233810-ebd112', '20261016-233811-c74974') |

通过 64 / 64