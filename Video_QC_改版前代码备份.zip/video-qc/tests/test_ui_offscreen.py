import json
import os
import sys
import time

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

from PySide6.QtWidgets import QApplication

from app.window import MainWindow
from videoqc.pipeline import run_pipeline

ASSETS = os.path.join(ROOT, "tests", "assets")
OUT = os.path.join(ROOT, "tests", "acceptance_out", "UI_SMOKE")
RESULTS = []
MSGBOX = []


def check(name, cond, detail=""):
    RESULTS.append((name, bool(cond), str(detail)[:200]))
    print("[smoke] %s -> %s (%s)" % (name, "PASS" if cond else "FAIL", detail), flush=True)
    return bool(cond)


def main():
    print("[smoke] boot offscreen QApplication", flush=True)
    app = QApplication([])
    MSGBOX.clear()

    def rec(kind):
        def f(self, title, text):
            MSGBOX.append((kind, title, text))
        return f

    MainWindow._warn = rec("warn")
    MainWindow._info = rec("info")
    MainWindow._error = rec("error")

    print("[smoke] construct MainWindow", flush=True)
    win = MainWindow()

    print("[smoke] step1 select video (probe)", flush=True)
    win.video_edit.setText(os.path.join(ASSETS, "L01.mp4"))
    win.load_video(os.path.join(ASSETS, "L01.mp4"))
    check("S1 选视频（元数据读取）", "显示" in win.video_info.text(), win.video_info.text())

    print("[smoke] step2 set ROI (same values as drag result)", flush=True)
    win.dyn_roi = [0.06, 0.72, 0.94, 0.86]
    win.lbl_dyn.setText(str(win.dyn_roi))
    win.chk_fixed.setChecked(True)
    win.fixed_roi = [0.55, 0.87, 0.98, 0.99]
    win.lbl_fixed.setText(str(win.fixed_roi))
    check("S2 设 ROI（动态+固定）", win.dyn_roi is not None and win.fixed_roi is not None, "")

    print("[smoke] step2b ROI dialog constructs (real frame render + canvas)", flush=True)
    from PySide6.QtGui import QColor
    from app.window import RoiDialog
    dlg_err = ""
    try:
        dlg = RoiDialog(win.video_edit.text().strip(), win.meta, QColor(37, 99, 235), None, None)
        ok = dlg.canvas.pixmap() is not None
    except Exception as e:
        ok = False
        dlg_err = repr(e)
    check("S2b ROI 弹窗可构建（真实抽帧渲染，防回归 21:15 修复项）", ok, dlg_err)

    print("[smoke] step3 script + provider", flush=True)
    win.script_box.setPlainText("今天天气真好\n适合出门散步\n")
    check("S3a 新界面默认本机识别且更多设置已折叠",
          win.provider.currentData() == "rapidocr" and not win.more_box.isChecked(),
          "%s/%s" % (win.provider.currentData(), win.more_box.isChecked()))
    win.set_provider("scripted")
    win.scripted_path.setText(os.path.join(ASSETS, "L01_scripted_ocr.json"))

    print("[smoke] step3b position band config (new in iter-4)", flush=True)
    cfg_probe, _ = win._collect_cfg()
    band = cfg_probe["dynamic_subtitles"]["expected_band"]
    check("S3b 位置检测默认开启且标准带合法（迭代四新增）",
          isinstance(band, list) and len(band) == 4 and 0.5 <= band[1] < band[3] <= 1.0, band)
    from videoqc.scriptparse import parse_script
    pres = parse_script("第一场 医院\n\n李明（激动）：今天天气真好\n适合出门散步\n（他站起身）\n王芳：好")
    check("S3c 剧本解析提取台词与剔除（迭代四新增）",
          pres.stats.get("parsed") and pres.plain_text == "今天天气真好 适合出门散步\n好"
          and pres.stats.get("dialogue_count") == 2
          and pres.stats.get("removed", {}).get("scene") == 1
          and pres.stats.get("removed", {}).get("stage_direction") == 1,
          pres.plain_text)
    win.chk_band.setChecked(False)

    print("[smoke] step3d re-parse protection (dialogue meta fix)", flush=True)
    win.script_box.setPlainText("今天天气真好 适合出门散步")
    win.script_meta = {"plain_text": "今天天气真好 适合出门散步", "lines": []}
    MSGBOX.clear()
    win.parse_script_text()
    check("S3d 对解析结果重复点击解析被拦截且元数据保留（界面修复新增）",
          bool(MSGBOX) and MSGBOX[-1][1] == "已经是解析结果" and win.script_meta is not None,
          [t for _, t, _ in MSGBOX])
    win.script_meta = None

    print("[smoke] step4 guard: empty script blocked before start", flush=True)
    win.script_box.setPlainText("")
    win.start()
    check("S4a 空原稿开始前拦截（未启动检测）", any("原稿" in t for _, _, t in MSGBOX), [t for _, _, t in MSGBOX])
    win.script_box.setPlainText("今天天气真好\n适合出门散步\n")

    print("[smoke] step4 guard: missing dyn ROI blocked", flush=True)
    saved = win.dyn_roi
    win.dyn_roi = None
    MSGBOX.clear()
    win.start()
    check("S4b 缺动态 ROI 开始前拦截", any("ROI" in t for _, _, t in MSGBOX), [t for _, _, t in MSGBOX])
    win.dyn_roi = saved

    print("[smoke] step5 start detection (sync pipeline, same cfg as UI start)", flush=True)
    MSGBOX.clear()
    cfg, script_text = win._collect_cfg()
    os.makedirs(OUT, exist_ok=True)
    t0 = time.time()
    result = run_pipeline(cfg, script_text, out_root=OUT)
    elapsed = time.time() - t0
    win.on_done(result)
    check("S5 检测流程执行完毕（%.1fs）" % elapsed, result["run_status"] == "completed", result["run_status"])

    print("[smoke] step6 report generated", flush=True)
    run_dir = os.path.join(OUT, result["run_id"])
    report = os.path.join(run_dir, "report.html")
    check("S6a 报告文件生成", os.path.isfile(report), report)
    check("S6b 界面状态栏呈现两项检查结果", "检查一" in win.status.text(), win.status.text())
    check("S6c 检查一 no_issue_observed", result["checks"]["script_alignment"] == "no_issue_observed",
          result["checks"])
    check("S6d 检查二 no_issue_observed", result["checks"]["dynamic_single_line"] == "no_issue_observed",
          result["checks"])
    check("S6e 输出目录结构完整",
          all(os.path.isfile(os.path.join(run_dir, n)) for n in
              ("report.html", "result.json", "config.snapshot.json", "run.log"))
          and os.path.isdir(os.path.join(run_dir, "evidence"))
          and os.path.isdir(os.path.join(run_dir, "raw")), run_dir)
    snap = json.load(open(os.path.join(run_dir, "config.snapshot.json"), encoding="utf-8"))
    check("S6f 快照不含密钥", "access_key" not in json.dumps(snap), "")

    print("[smoke] step7 rerun produces new run dir", flush=True)
    result2 = run_pipeline(cfg, script_text, out_root=OUT)
    run_dir2 = os.path.join(OUT, result2["run_id"])
    check("S7 重跑生成独立目录", result2["run_id"] != result["run_id"]
          and os.path.isfile(os.path.join(run_dir2, "report.html")), result2["run_id"])

    passed = sum(1 for x in RESULTS if x[1])
    md = os.path.join(ROOT, "tests", "acceptance_ui.md")
    lines = ["# Video QC V1 界面冒烟测试记录（offscreen 自动化）", "",
             "执行时间：%s" % time.strftime("%Y-%m-%d %H:%M:%S"), "",
             "冒烟路径：选视频 → 设 ROI → 开始检测 → 生成报告。",
             "说明：检测以界面组装的同一份配置同步执行（与点击开始按钮后 Worker 线程执行的 run_pipeline 为同一函数与同一配置来源）；",
             "真实窗口模式下的 ROI 拖拽交互与后台线程异步进度展示，仍需人工运行 python main.py 复核。",
             "", "| 断言 | 结果 | 说明 |", "|---|---|---|"]
    for name, ok_, detail in RESULTS:
        lines.append("| %s | %s | %s |" % (name, "通过" if ok_ else "未通过", detail.replace("|", "/").replace("\n", " ")))
    lines.append("")
    lines.append("通过 %d / %d" % (passed, len(RESULTS)))
    with open(md, "w", encoding="utf-8") as f:
        f.write("\n".join(lines))
    print("\n[smoke] %d/%d passed -> %s" % (passed, len(RESULTS), md), flush=True)
    if passed != len(RESULTS):
        sys.exit(1)


if __name__ == "__main__":
    main()
