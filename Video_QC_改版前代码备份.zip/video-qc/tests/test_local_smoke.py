import json
import os
import sys
import time

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

from videoqc import config as cfg_mod
from videoqc.pipeline import load_script, run_pipeline

ASSETS = os.path.join(ROOT, "tests", "assets")
OUT = os.path.join(ROOT, "tests", "acceptance_out", "LOCAL_SMOKE")
RESULTS = []


def check(name, cond, detail=""):
    RESULTS.append((name, bool(cond), str(detail)[:220]))
    print("[local-smoke] %s -> %s (%s)" % (name, "PASS" if cond else "FAIL", detail), flush=True)
    return bool(cond)


def main():
    cfg = cfg_mod.load_config(os.path.join(ROOT, "config.example.local.json"))
    script_text = load_script(cfg["script_path"])
    errors, _ = cfg_mod.validate_config(
        cfg, video_exists=os.path.isfile(cfg["video_path"]), script_text=script_text)
    check("LS0 本地配置校验通过（无密钥、无上传确认要求）", not errors, errors)

    os.makedirs(OUT, exist_ok=True)
    print("[local-smoke] start local rapidocr pipeline on L01.mp4", flush=True)
    t0 = time.time()
    result = run_pipeline(cfg, script_text, out_root=OUT)
    elapsed = time.time() - t0

    info = result.get("run_info", {})
    cov = result.get("coverage", {})
    print("[local-smoke] elapsed %.1fs | calls=%s errors=%s | status=%s"
          % (elapsed, info.get("ocr_calls"), info.get("ocr_errors"), result.get("run_status")), flush=True)

    check("LS1 运行结束且不失败（completed/partial）",
          result.get("run_status") in ("completed", "partial"), result.get("run_status"))
    check("LS2 本地 OCR 真实调用全部成功（无调用失败）",
          (info.get("ocr_errors") or 0) == 0, info.get("ocr_errors"))
    check("LS3 检查二状态可用（识别到动态字幕）",
          result.get("checks", {}).get("dynamic_single_line") not in (None, "unavailable"),
          result.get("checks"))
    check("LS4 检查一状态可用（可对齐）",
          result.get("checks", {}).get("script_alignment") not in (None, "unavailable"),
          result.get("checks"))
    events = result.get("events", [])
    texts = [e.get("text", "") for e in events]
    check("LS5 真实识别出字幕事件（非预制结果）",
          len(events) >= 1 and any("天气" in t or "散步" in t for t in texts), texts)
    run_dir = os.path.join(OUT, result.get("run_id", ""))
    check("LS6 报告与输出结构完整",
          os.path.isfile(os.path.join(run_dir, "report.html"))
          and os.path.isfile(os.path.join(run_dir, "result.json"))
          and os.path.isdir(os.path.join(run_dir, "raw")), run_dir)
    check("LS7 快照不含密钥且零费用",
          "access_key" not in json.dumps(json.load(open(os.path.join(run_dir, "config.snapshot.json"), encoding="utf-8")))
          and (info.get("cost_estimate_yuan") or 0) == 0, info.get("cost_estimate_yuan"))
    per_frame = elapsed / max(1, cov.get("processed_samples") or 1)
    check("LS8 性能可接受（CPU 本地，均耗 < 3s/帧）", per_frame < 3.0, "%.2fs/帧" % per_frame)

    passed = sum(1 for x in RESULTS if x[1])
    md = os.path.join(ROOT, "tests", "acceptance_local.md")
    lines = [
        "# Video QC V1 本地 OCR 后端（rapidocr）冒烟测试记录",
        "",
        "执行时间：%s" % time.strftime("%Y-%m-%d %H:%M:%S"),
        "后端：rapidocr（PP-OCRv4 ONNX 检测+识别，本地推理，CPU）",
        "样本：受控合成 MP4（L01，真实视频帧真实 OCR 推理，非预制结果）",
        "总耗时 %.1fs ｜ 调用 %s 次 ｜ 失败 %s 次 ｜ 均耗 %.2fs/帧"
        % (elapsed, info.get("ocr_calls"), info.get("ocr_errors"), per_frame),
        "",
        "| 断言 | 结果 | 说明 |",
        "|---|---|---|",
    ]
    for name, ok_, detail in RESULTS:
        lines.append("| %s | %s | %s |" % (name, "通过" if ok_ else "未通过", detail.replace("|", "/").replace("\n", " ")))
    lines.append("")
    lines.append("通过 %d / %d" % (passed, len(RESULTS)))
    lines.append("")
    lines.append("说明：本次为本地后端冒烟；真实成片识别效果与阈值调优待真实样本到位后另行记录。")
    with open(md, "w", encoding="utf-8") as f:
        f.write("\n".join(lines))
    print("\n[local-smoke] %d/%d passed -> %s" % (passed, len(RESULTS), md), flush=True)
    if passed != len(RESULTS):
        sys.exit(1)


if __name__ == "__main__":
    main()
