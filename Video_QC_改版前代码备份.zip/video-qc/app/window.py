import json
import os
import sys
import traceback

from PySide6.QtCore import Qt, QThread, Signal, QUrl
from PySide6.QtGui import QDesktopServices, QPainter, QColor, QPen, QPixmap
from PySide6.QtWidgets import (
    QApplication, QCheckBox, QComboBox, QDialog, QDoubleSpinBox, QFileDialog,
    QFormLayout, QGroupBox, QHBoxLayout, QLabel, QLineEdit, QMainWindow,
    QMessageBox, QProgressBar, QPushButton, QSpinBox, QTextEdit, QVBoxLayout,
    QWidget,
)

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from videoqc import SCHEMA_VERSION
from videoqc import config as cfg_mod
from videoqc.config import DEFAULT_SUBTITLE_BAND
from videoqc.evidence import render_full_frame, annotate_rois
from videoqc.pipeline import load_script, run_pipeline
from videoqc.providers import CREDENTIALS_FILENAME, resolve_aliyun_credentials
from videoqc.scriptparse import parse_script as parse_script_text_impl
from videoqc.video import probe_video

DYN_COLOR = QColor(37, 99, 235)
FIX_COLOR = QColor(217, 119, 6)

PROVIDER_LABELS = [
    ("本机识别（推荐：不上传、免费）", "rapidocr"),
    ("云端识别（阿里云：上传字幕裁剪图）", "aliyun"),
    ("演示预制数据（联调用）", "scripted"),
]

PROVIDER_HINTS = {
    "rapidocr": "在本机完成识别：不上传任何画面、免配置、免费；速度约每秒 1 帧，一般几分钟内完成。适合日常使用。",
    "aliyun": "使用阿里云识别：仅上传字幕区域的裁剪图（不传完整视频），需要密钥。本机识别效果不理想时再考虑。",
    "scripted": "使用预制演示数据：不识别视频，仅用于演示与联调。",
}

STAGE_CN = {
    "probe": "读取视频信息",
    "plan": "规划抽帧",
    "sample": "抽取画面帧",
    "ocr": "识别字幕",
    "classify": "归类字幕",
    "align": "比对原稿",
    "write": "生成报告",
}


class RoiCanvas(QLabel):
    def __init__(self, pixmap, parent_dialog):
        super().__init__()
        self.parent_dialog = parent_dialog
        self.full = pixmap
        self.origin = None
        self.rect = None
        self.color = parent_dialog.color
        self.setAlignment(Qt.AlignCenter)
        self.setMinimumSize(420, 420)
        self._scaled = self.full.scaled(self.size(), Qt.KeepAspectRatio, Qt.SmoothTransformation)
        self.setPixmap(self._scaled)

    def resizeEvent(self, e):
        self._scaled = self.full.scaled(self.size(), Qt.KeepAspectRatio, Qt.SmoothTransformation)
        self._repaint()

    def _to_full(self, pos):
        sp = self._scaled.size()
        off_x = (self.width() - sp.width()) / 2.0
        off_y = (self.height() - sp.height()) / 2.0
        fx = (pos.x() - off_x) * self.full.width() / max(1, sp.width())
        fy = (pos.y() - off_y) * self.full.height() / max(1, sp.height())
        return fx, fy

    def mousePressEvent(self, e):
        self.origin = self._to_full(e.position())
        self.rect = (self.origin[0], self.origin[1], self.origin[0], self.origin[1])
        self._repaint()

    def mouseMoveEvent(self, e):
        if self.origin is None:
            return
        x, y = self._to_full(e.position())
        self.rect = (self.origin[0], self.origin[1], x, y)
        self._repaint()

    def mouseReleaseEvent(self, e):
        if self.rect:
            self.parent_dialog.on_rect(self.rect)
        self.origin = None

    def _repaint(self):
        pm = self._scaled.copy()
        p = QPainter(pm)
        p.setPen(QPen(self.color, 3))
        r = self.rect
        if r:
            sp = self._scaled.size()
            off_x = (self.width() - sp.width()) / 2.0
            off_y = (self.height() - sp.height()) / 2.0
            sx = sp.width() / self.full.width()
            sy = sp.height() / self.full.height()
            p.drawRect(int(off_x + min(r[0], r[2]) * sx), int(off_y + min(r[1], r[3]) * sy),
                       int(abs(r[2] - r[0]) * sx), int(abs(r[3] - r[1]) * sy))
        p.end()
        self.setPixmap(pm)

    def set_rois(self, dyn, fixed):
        pil = render_full_frame(self.parent_dialog.video_path, self.parent_dialog.meta,
                                int(self.parent_dialog.t_ms))
        annotate_rois(pil, dyn, fixed)
        import PIL.ImageQt
        self.full = PIL.ImageQt.toqpixmap(pil)
        self._scaled = self.full.scaled(self.size(), Qt.KeepAspectRatio, Qt.SmoothTransformation)
        self._repaint()


class RoiDialog(QDialog):
    def __init__(self, video_path, meta, color, existing, other_roi, parent=None):
        super().__init__(parent)
        self.setWindowTitle("拖拽矩形选择区域（仅限画面下半区）")
        self.video_path = video_path
        self.meta = meta
        self.color = color
        self.result_roi = None
        self.t_ms = int((meta.get("duration_s") or 1) * 500)

        pil = render_full_frame(video_path, meta, self.t_ms)
        if existing:
            annotate_rois(pil, existing, None)
        self.canvas = RoiCanvas(_pil_to_pixmap(pil), self)
        if other_roi:
            self.canvas.other = other_roi

        tip = QLabel("在预览画面上按住鼠标左键拖出一个矩形；区域会被限制在下半区（y ≥ 0.5）。")
        tip.setWordWrap(True)
        btns = QHBoxLayout()
        ok = QPushButton("确认")
        cancel = QPushButton("取消")
        ok.clicked.connect(self.accept)
        cancel.clicked.connect(self.reject)
        btns.addStretch(1)
        btns.addWidget(ok)
        btns.addWidget(cancel)
        lay = QVBoxLayout(self)
        lay.addWidget(self.canvas)
        lay.addWidget(tip)
        lay.addLayout(btns)

    def on_rect(self, r):
        W = self.meta["display_width"]
        H = self.meta["display_height"]
        x0 = min(r[0], r[2]) / W
        x1 = max(r[0], r[2]) / W
        y0 = min(r[1], r[3]) / H
        y1 = max(r[1], r[3]) / H
        x0, x1 = max(0.0, min(1.0, x0)), max(0.0, min(1.0, x1))
        y0, y1 = max(0.5, min(1.0, y0)), max(0.5, min(1.0, y1))
        if x1 - x0 > 0.01 and y1 - y0 > 0.01:
            self.result_roi = [round(x0, 4), round(y0, 4), round(x1, 4), round(y1, 4)]
        else:
            self.result_roi = None


def _pil_to_pixmap(pil):
    import PIL.ImageQt
    return PIL.ImageQt.toqpixmap(pil)


class Worker(QThread):
    progress = Signal(str, str, int)
    done = Signal(dict)
    failed = Signal(str)

    def __init__(self, cfg, script_text, out_root, credentials):
        super().__init__()
        self.cfg = cfg
        self.script_text = script_text
        self.out_root = out_root
        self.credentials = credentials

    def run(self):
        try:
            result = run_pipeline(
                self.cfg, self.script_text, out_root=self.out_root,
                progress=lambda s, d, p: self.progress.emit(s, d, p),
                credentials=self.credentials,
            )
            self.done.emit(result)
        except Exception:
            self.failed.emit(traceback.format_exc()[-800:])


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Video QC V1 精简版（原稿核对 + 动态字幕严格单行）")
        self.meta = None
        self.dyn_roi = None
        self.fixed_roi = None
        self.last_report = None
        self.worker = None
        self.script_meta = None
        self._build_ui()

    def _build_ui(self):
        central = QWidget()
        self.setCentralWidget(central)
        root = QVBoxLayout(central)

        head = QLabel(
            "<b style='font-size:15px'>视频字幕核对助手</b><br>"
            "<span style='color:#6b7280'>三步完成：选成片 → 贴原稿 → 圈字幕区；"
            "其余参数已默认调好，需要时再展开「更多设置」。</span>")
        head.setTextFormat(Qt.RichText)
        root.addWidget(head)

        g1 = QGroupBox("① 选择成片")
        f1 = QFormLayout(g1)
        self.video_edit = QLineEdit()
        vb = QPushButton("选择视频…")
        vb.clicked.connect(self.pick_video)
        row = QHBoxLayout()
        row.addWidget(self.video_edit)
        row.addWidget(vb)
        f1.addRow("视频文件：", row_item(row))
        self.video_info = QLabel("未选择")
        self.video_info.setStyleSheet("color:#6b7280")
        f1.addRow(self.video_info, QLabel(""))

        g2 = QGroupBox("② 上传 / 粘贴剧本原稿")
        f2 = QFormLayout(g2)
        hb = QPushButton("从文件载入…")
        hb.clicked.connect(self.pick_script)
        pb = QPushButton("解析剧本（自动提取台词）")
        pb.clicked.connect(self.parse_script_text)
        srow = QHBoxLayout()
        srow.addWidget(hb)
        srow.addWidget(pb)
        self.script_box = QTextEdit()
        self.script_box.setPlaceholderText(
            "可直接粘贴完整剧本（支持「角色名：台词」格式），再点「解析剧本」自动提取台词；\n"
            "也可粘贴已清理好的纯台词。")
        f2.addRow(row_item(srow), self.script_box)

        g3 = QGroupBox("③ 圈出字幕区域")
        f3 = QFormLayout(g3)
        self.btn_dyn = QPushButton("圈出字幕出现的区域…")
        self.btn_dyn.clicked.connect(self.set_dyn_roi)
        self.btn_band = QPushButton("使用标准字幕位置")
        self.btn_band.clicked.connect(self.apply_band)
        drow = QHBoxLayout()
        drow.addWidget(self.btn_dyn)
        drow.addWidget(self.btn_band)
        self.lbl_dyn = QLabel("未设置（必填；或直接点右侧使用标准位置）")
        f3.addRow(row_item(drow), self.lbl_dyn)

        g4 = QGroupBox("识别方式")
        f4 = QFormLayout(g4)
        self.provider = QComboBox()
        for label, val in PROVIDER_LABELS:
            self.provider.addItem(label, val)
        f4.addRow("方式：", self.provider)
        self.provider_hint = QLabel("")
        self.provider_hint.setStyleSheet("color:#6b7280")
        self.provider_hint.setWordWrap(True)
        f4.addRow(self.provider_hint, QLabel(""))
        self.scripted_panel = QWidget()
        sf = QFormLayout(self.scripted_panel)
        sf.setContentsMargins(0, 0, 0, 0)
        self.scripted_path = QLineEdit()
        sf.addRow("演示数据文件（JSON）：", self.scripted_path)
        f4.addRow(self.scripted_panel, QLabel(""))
        self.aliyun_panel = QWidget()
        af = QFormLayout(self.aliyun_panel)
        af.setContentsMargins(0, 0, 0, 0)
        self.ak = QLineEdit()
        self.ak.setPlaceholderText("留空则读取环境变量或本地凭据文件")
        self.sk = QLineEdit()
        self.sk.setEchoMode(QLineEdit.Password)
        af.addRow("AccessKey ID：", self.ak)
        af.addRow("AccessKey Secret：", self.sk)
        self.upload_ok = QCheckBox("我已确认：云端仅接收字幕区域的裁剪图（不传完整视频）")
        af.addRow(self.upload_ok, QLabel(""))
        f4.addRow(self.aliyun_panel, QLabel(""))

        self.more_box = QGroupBox("更多设置（默认已调好，一般不用改）")
        self.more_box.setCheckable(True)
        self.more_inner = QWidget()
        mf = QFormLayout(self.more_inner)
        self.chk_fixed = QCheckBox("本片存在固定提示（如右下角常驻文字，两行也算正常）")
        self.chk_fixed.toggled.connect(self._toggle_fixed)
        self.btn_fixed = QPushButton("设置固定提示区域…")
        self.btn_fixed.setEnabled(False)
        self.btn_fixed.clicked.connect(self.set_fixed_roi)
        self.lbl_fixed = QLabel("—")
        mf.addRow(self.chk_fixed, self.lbl_fixed)
        mf.addRow(self.btn_fixed, QLabel(""))
        self.chk_band = QCheckBox("启用字幕位置检测（字幕超出标准带将写入报告）")
        self.chk_band.setChecked(True)
        mf.addRow(self.chk_band, QLabel(""))
        band_row = QHBoxLayout()
        self.band_spins = []
        for i, name in enumerate(("左", "上", "右", "下")):
            sp = QDoubleSpinBox()
            sp.setRange(0.0, 1.0)
            sp.setDecimals(4)
            sp.setSingleStep(0.01)
            sp.setValue(DEFAULT_SUBTITLE_BAND[i])
            band_row.addWidget(QLabel(name))
            band_row.addWidget(sp)
            self.band_spins.append(sp)
        mf.addRow("标准字幕带范围：", row_item(band_row))
        self.chk_punct = QCheckBox("忽略标点差异（推荐勾选：成片字幕一般不带标点）")
        self.chk_punct.setChecked(True)
        mf.addRow(self.chk_punct, QLabel(""))
        self.fps = QDoubleSpinBox()
        self.fps.setRange(0.1, 30.0)
        self.fps.setValue(2.0)
        self.fps.setDecimals(2)
        mf.addRow("抽样密度（每秒抽几帧）：", self.fps)
        self.timeout = QSpinBox()
        self.timeout.setRange(1000, 600000)
        self.timeout.setValue(20000)
        self.timeout.setSuffix(" ms")
        mf.addRow("云端单次超时：", self.timeout)
        self.retries = QSpinBox()
        self.retries.setRange(0, 10)
        self.retries.setValue(2)
        mf.addRow("失败自动重试：", self.retries)
        self.max_calls = QSpinBox()
        self.max_calls.setRange(1, 1000000)
        self.max_calls.setValue(5000)
        mf.addRow("调用次数上限（保险）：", self.max_calls)
        self.cost_call = QDoubleSpinBox()
        self.cost_call.setRange(0.0, 10.0)
        self.cost_call.setDecimals(4)
        self.cost_call.setValue(0.01)
        mf.addRow("单次费用估算（元）：", self.cost_call)
        self.max_cost = QDoubleSpinBox()
        self.max_cost.setRange(0.01, 1000000.0)
        self.max_cost.setValue(50.0)
        mf.addRow("单任务费用上限（元）：", self.max_cost)
        ml = QVBoxLayout(self.more_box)
        ml.addWidget(self.more_inner)
        self.more_box.toggled.connect(self.more_inner.setVisible)

        g5 = QGroupBox("开始")
        f5 = QFormLayout(g5)
        self.btn_start = QPushButton("开始检测")
        self.btn_start.setStyleSheet("font-weight:600;padding:8px;font-size:14px")
        self.btn_start.clicked.connect(self.start)
        f5.addRow(self.btn_start, QLabel(""))
        self.progress = QProgressBar()
        self.progress.setRange(0, 100)
        f5.addRow("进度：", self.progress)
        self.status = QLabel("待开始：完成上面三步即可开始")
        self.status.setWordWrap(True)
        f5.addRow("状态：", self.status)
        self.btn_report = QPushButton("打开问题报告")
        self.btn_report.setEnabled(False)
        self.btn_report.clicked.connect(self.open_report)
        f5.addRow(self.btn_report, QLabel(""))

        for g in (g1, g2, g3, g4, self.more_box, g5):
            root.addWidget(g)
        self.provider.currentIndexChanged.connect(self._toggle_provider)
        self.more_box.setChecked(False)
        self._toggle_provider()
        self.setGeometry(200, 120, 780, 940)

    def parse_script_text(self):
        text = self.script_box.toPlainText()
        if not text.strip():
            self._warn("没有可解析的内容", "请先粘贴或载入剧本原文")
            return
        res = parse_script_text_impl(text)
        if not res.stats.get("parsed"):
            if (self.script_meta
                    and text == (self.script_meta.get("plain_text") or "")):
                self._info(
                    "已经是解析结果",
                    "当前文本就是上次解析出的纯台词，无需重复解析（重复解析不会有效果）。\n"
                    "如需重新解析原始剧本，请先粘贴或载入剧本原文再点「解析剧本」。")
                return
            self._info(
                "未识别出剧本格式",
                "没有找到「角色名：台词」格式的行，已按纯台词文本处理（与原工作流一致）。\n"
                "如剧本确实带角色名，请检查是否使用冒号（：或:）分隔后重试。")
            self.script_meta = None
            return
        self.script_box.setPlainText(res.plain_text)
        self.script_meta = res.to_meta()
        st = res.stats
        rm = st.get("removed") or {}
        roles = "、".join(st.get("roles") or [])
        msg = (
            "解析完成：提取出 %d 条台词（角色 %d 个%s）。\n"
            "剔除非台词内容：场景标题 %d 行、舞台指示 %d 行、人物表 %d 行、空行 %d 行。\n"
            "另有 %d 行未能识别格式，已保留为台词（请人工检查，可手动删除）。\n\n"
            "提取结果已填入文本框，可继续手动修改；报告将按「台词序号 + 角色」定位。\n"
            "注意：手动修改文本框后，台词序号定位将不生效（开始检测时会提醒）。"
            % (st.get("dialogue_count", 0), len(st.get("roles") or []),
               ("（%s）" % roles) if roles else "",
               rm.get("scene", 0), rm.get("stage_direction", 0),
               rm.get("cast_list", 0), rm.get("blank", 0),
               st.get("unlabeled_kept", 0)))
        self._info("剧本解析完成", msg)

    def apply_band(self):
        band = [round(sp.value(), 4) for sp in self.band_spins]
        if not cfg_mod.roi_valid(band):
            self._warn("标准带数值无效", "请检查「更多设置」中的标准字幕带范围（需 0~1 且有正面积）")
            return
        self.dyn_roi = band
        self.lbl_dyn.setText("已使用标准字幕位置 %s（可再拖框微调）" % band)

    def _toggle_fixed(self, on):
        self.btn_fixed.setEnabled(on)
        if not on:
            self.fixed_roi = None
            self.lbl_fixed.setText("—")

    def _toggle_provider(self, *_):
        v = self.provider.currentData() or "rapidocr"
        self.scripted_panel.setVisible(v == "scripted")
        self.aliyun_panel.setVisible(v == "aliyun")
        self.provider_hint.setText(PROVIDER_HINTS.get(v, ""))

    def set_provider(self, value):
        idx = self.provider.findData(value)
        if idx >= 0:
            self.provider.setCurrentIndex(idx)

    def pick_video(self):
        path, _ = QFileDialog.getOpenFileName(self, "选择成片", "", "视频 (*.mp4 *.mov *.mkv *.m4v)")
        if not path:
            return
        self.load_video(path)

    def load_video(self, path):
        self.video_edit.setText(path)
        try:
            self.meta = probe_video(path)
            self.dyn_roi = None
            self.fixed_roi = None
            self.lbl_dyn.setText("未设置（视频已更换，需重新设置 ROI）")
            self.lbl_fixed.setText("—")
            self.video_info.setText(
                "显示 %d×%d（rotation %s°）· 时长 %.1fs · %s音轨"
                % (self.meta["display_width"], self.meta["display_height"], self.meta["rotation"],
                   self.meta["duration_s"] or 0, "含" if self.meta["has_audio"] else "无")
            )
        except Exception as e:
            self.meta = None
            self.video_info.setText("读取失败：%s（请确认文件是有效视频且未被其他程序占用）" % e)

    def _warn(self, title, text):
        QMessageBox.warning(self, title, text)

    def _info(self, title, text):
        QMessageBox.information(self, title, text)

    def _error(self, title, text):
        QMessageBox.critical(self, title, text)

    def pick_script(self):
        path, _ = QFileDialog.getOpenFileName(self, "载入原稿（UTF-8 TXT/MD）", "", "文本 (*.txt *.md *.TXT *.MD)")
        if not path:
            return
        try:
            self.script_meta = None
            self.script_box.setPlainText(load_script(path))
        except cfg_mod.ConfigError as e:
            self._error("原稿载入失败", str(e))

    def set_dyn_roi(self):
        roi = self._ask_roi(DYN_COLOR, self.dyn_roi, None, "动态字幕")
        if roi:
            self.dyn_roi = roi
            self.lbl_dyn.setText(str(roi))

    def set_fixed_roi(self):
        roi = self._ask_roi(FIX_COLOR, self.fixed_roi, self.dyn_roi, "固定提示")
        if roi:
            self.fixed_roi = roi
            self.lbl_fixed.setText(str(roi))

    def _ask_roi(self, color, existing, other, name):
        if not self._require_video():
            return None
        try:
            dlg = RoiDialog(self.video_edit.text().strip(), self.meta, color, existing, other, parent=self)
            if dlg.exec() == QDialog.Accepted and dlg.result_roi:
                return dlg.result_roi
        except Exception as e:
            self._error("%s区域窗口打开失败" % name,
                        "发生内部错误，请把以下信息反馈给开发者：\n%s" % (str(e)[:400]))
        return None

    def _require_video(self):
        path = self.video_edit.text().strip()
        if not path or not os.path.isfile(path):
            self._warn("缺少视频", "请先选择有效的成片文件")
            return False
        if self.meta is None:
            try:
                self.meta = probe_video(path)
            except Exception as e:
                self._warn("视频读取失败", str(e))
                return False
        return True

    def _collect_cfg(self):
        video = self.video_edit.text().strip()
        script_text = self.script_box.toPlainText()
        present = self.chk_fixed.isChecked()
        provider = self.provider.currentData() or "rapidocr"
        cloud = {
            "ocr_enabled": True,
            "provider": provider,
            "upload_confirmed": self.upload_ok.isChecked(),
            "max_calls_per_job": self.max_calls.value(),
            "max_cost_per_job": self.max_cost.value(),
            "cost_per_call": self.cost_call.value(),
            "timeout_ms": self.timeout.value(),
            "max_retries": self.retries.value(),
        }
        if provider == "scripted":
            cloud["scripted_path"] = self.scripted_path.text().strip()
        elif provider == "rapidocr":
            cloud["cost_per_call"] = 0.0
        else:
            cloud["endpoint"] = "ocr-api.cn-hangzhou.aliyuncs.com"
        expected_band = None
        if self.chk_band.isChecked():
            expected_band = [round(sp.value(), 4) for sp in self.band_spins]
            if not cfg_mod.roi_valid(expected_band):
                expected_band = None
        script_lines = None
        if (self.script_meta
                and self.script_box.toPlainText() == self.script_meta.get("plain_text")):
            script_lines = self.script_meta.get("lines")
        return {
            "schema_version": SCHEMA_VERSION,
            "video_path": video,
            "script_path": None,
            "capture": {"region_box": [0, 0.5, 1, 1]},
            "dynamic_subtitles": {"max_lines": 1, "roi": self.dyn_roi, "expected_band": expected_band},
            "fixed_notice": {
                "present": present,
                "roi": self.fixed_roi if present else None,
                "exclude_from_dynamic_line_count": True,
                "exclude_from_script_alignment": True,
            },
            "text_normalization": {
                "ignore_whitespace": False,
                "ignore_punctuation": self.chk_punct.isChecked(),
            },
            "sampling": {"base_fps": self.fps.value()},
            "geometry": {"duplicate_box_tolerance": 0.85, "same_line_tolerance": 0.5},
            "event_grouping": {"text_similarity_threshold": 0.75, "max_gap_ms": 1200},
            "cloud": cloud,
            "script_lines": script_lines,
        }, script_text

    def start(self):
        cfg, script_text = self._collect_cfg()
        video = cfg["video_path"]
        errors, warns = cfg_mod.validate_config(
            cfg, video_exists=(os.path.isfile(video) if video else False), script_text=script_text)
        if errors:
            self._warn("开始前需补齐输入", "\n".join(errors))
            return
        if warns:
            self._info("提示", "\n".join(warns))
        if (self.script_meta
                and self.script_box.toPlainText() != (self.script_meta.get("plain_text") or "")):
            self._info(
                "台词定位提示",
                "检测到台词文本在解析后已被手动修改，报告将按原稿段落定位\n"
                "（「台词序号 + 角色」定位本次不生效）。")

        credentials = None
        if cfg["cloud"]["provider"] == "aliyun":
            ak = self.ak.text().strip()
            sk = self.sk.text().strip()
            if ak and sk:
                credentials = {"access_key_id": ak, "access_key_secret": sk}
                self._save_credentials(ak, sk)
            else:
                rid, rsk = resolve_aliyun_credentials()
                if not rid:
                    self._warn("缺少 OCR 凭据",
                              "请填写阿里云 AccessKey，或设置环境变量 ALIBABA_CLOUD_ACCESS_KEY_ID / "
                              "ALIBABA_CLOUD_ACCESS_KEY_SECRET，或配置 %s" % CREDENTIALS_FILENAME)
                    return

        self.btn_start.setEnabled(False)
        self.status.setText("正在启动…")
        self.progress.setValue(0)
        out_root = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "output")
        self.worker = Worker(cfg, script_text, os.path.abspath(out_root), credentials)
        self.worker.progress.connect(self.on_progress)
        self.worker.done.connect(self.on_done)
        self.worker.failed.connect(self.on_failed)
        self.worker.start()

    def _save_credentials(self, ak, sk):
        try:
            os.makedirs(os.path.dirname(CREDENTIALS_FILENAME), exist_ok=True)
            with open(CREDENTIALS_FILENAME, "w", encoding="utf-8") as f:
                json.dump({"aliyun_access_key_id": ak, "aliyun_access_key_secret": sk}, f)
            self.status.setText("凭据已保存到本地文件（不写入配置快照与报告）")
        except OSError:
            pass

    def on_progress(self, stage, detail, pct):
        self.progress.setValue(max(0, min(100, pct)))
        self.status.setText("%s：%s" % (STAGE_CN.get(stage, stage), detail))

    def on_done(self, result):
        self.btn_start.setEnabled(True)
        st = result.get("run_status")
        self.status.setText(
            "运行 %s ｜ 检查一（原稿核对）：%s ｜ 检查二（严格单行）：%s ｜ 检查三（字幕位置）：%s ｜ 问题 %d 项（疑似 %d / 不确定 %d）"
            % (st, result.get("checks", {}).get("script_alignment"),
               result.get("checks", {}).get("dynamic_single_line"),
               result.get("checks", {}).get("subtitle_position"),
               len(result.get("issues", [])),
               sum(1 for i in result.get("issues", []) if i.get("status") == "suspected"),
               sum(1 for i in result.get("issues", []) if i.get("status") == "inconclusive"))
        )
        if st == "needs_input":
            self._warn("待补输入", "\n".join(result.get("errors", [])))
            return
        if st == "failed":
            self._error("运行失败", "\n".join(result.get("errors", [])[:5]) or "无法产生可用核心结果")
        run_dir = result.get("run_id")
        if run_dir:
            base = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "output"))
            self.last_report = os.path.join(base, run_dir, "report.html")
            self.btn_report.setEnabled(os.path.isfile(self.last_report))
        if result.get("warnings"):
            self._info("运行完成（含警告）", "\n".join(result["warnings"][:8]))

    def on_failed(self, msg):
        self.btn_start.setEnabled(True)
        self.status.setText("执行异常")
        self._error("执行异常", msg)

    def open_report(self):
        if self.last_report and os.path.isfile(self.last_report):
            QDesktopServices.openUrl(QUrl.fromLocalFile(self.last_report))


def row_item(layout):
    w = QWidget()
    w.setLayout(layout)
    return w


def main():
    app = QApplication(sys.argv)
    win = MainWindow()
    win.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
